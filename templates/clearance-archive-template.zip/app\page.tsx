import { Console } from '@/components/Console'
import { CommandPalette } from '@/components/CommandPalette'
import { Contact } from '@/components/Contact'
import { DocumentPane } from '@/components/DocumentPane'
import { Footer } from '@/components/Footer'
import { GrantFlash } from '@/components/GrantFlash'
import { Ladder } from '@/components/Ladder'
import { Capabilities, Identity } from '@/components/Levels'
import { Notes } from '@/components/Notes'
import { Probe } from '@/components/Probe'
import { Section } from '@/components/Section'
import { Signals } from '@/components/Signals'
import { Texture } from '@/components/Texture'
import { Work } from '@/components/Work'
import { notes, projects, site } from '@/content/site'

import Vaultline from '@/content/projects/vaultline.mdx'
import Patchwork from '@/content/projects/patchwork.mdx'
import Quietroom from '@/content/projects/quietroom.mdx'
import Papertrail from '@/content/projects/papertrail.mdx'
import Signalfire from '@/content/projects/signalfire.mdx'
import Redaction from '@/content/notes/redaction-is-material.mdx'
import Csp from '@/content/notes/csp-is-a-style-guide.mdx'
import Pencil from '@/content/notes/threat-modeling-with-a-pencil.mdx'
import Dark from '@/content/notes/dark-patterns-are-vulns.mdx'
import Omega from '@/content/notes/omega.mdx'

/*
  MDX dossiers are compiled on the server and handed to the client components
  as rendered nodes. The page is dynamically rendered because the CSP nonce is
  per-request — the price of a CSP without 'unsafe-inline'.
*/
const projectBodies = {
  vaultline: <Vaultline />,
  patchwork: <Patchwork />,
  quietroom: <Quietroom />,
  papertrail: <Papertrail />,
  signalfire: <Signalfire />,
}
const noteBodies = {
  'redaction-is-material': <Redaction />,
  'csp-is-a-style-guide': <Csp />,
  'threat-modeling-with-a-pencil': <Pencil />,
  'dark-patterns-are-vulns': <Dark />,
}

const files = [
  ...projects.map((p) => ({ kind: 'project', slug: p.slug, code: p.code, title: p.title })),
  ...notes.map((n) => ({ kind: 'note', slug: n.slug, code: n.code, title: n.title })),
  { kind: 'note', slug: 'omega', code: 'NOTE Ω', title: '████████ (sealed)' },
]

export default function Page() {
  return (
    <>
      <Texture />
      <Signals />
      <a href="#identity" className="skip-link">
        Skip to archive
      </a>

      <div className="frame">
        <Ladder />
        <Console />
        <DocumentPane>
          <Section level={1}>
            <Identity />
          </Section>
          <Section level={2}>
            <Work items={projects} bodies={projectBodies} />
          </Section>
          <Section level={3}>
            <Capabilities />
          </Section>
          <Section level={4}>
            <Notes items={notes} bodies={noteBodies} omega={<Omega />} />
          </Section>
          <Section level={5}>
            <Contact />
          </Section>
          <Footer />
        </DocumentPane>
      </div>

      {/* Print-only appendix: every case file and note, fully declassified. */}
      <div className="print-appendix" aria-hidden="true">
        <h1 className="font-serif">{site.name} — Case files</h1>
        {projects.map((p) => (
          <article key={p.slug} className="print-file">
            <div className="print-meta">
              {p.code} · {p.year} · {p.role} · {p.stack}
            </div>
            <h2 className="font-serif">{p.title}</h2>
            <p>
              <b>Security —</b> {p.security} <b>Design —</b> {p.design} <b>Outcome —</b> {p.outcome}
            </p>
            {projectBodies[p.slug as keyof typeof projectBodies]}
          </article>
        ))}
        {notes.map((n) => (
          <article key={n.slug} className="print-file">
            <div className="print-meta">
              {n.code} · {n.date}
            </div>
            <h2 className="font-display">{n.title}</h2>
            {noteBodies[n.slug as keyof typeof noteBodies]}
          </article>
        ))}
      </div>

      <Probe />
      <GrantFlash />
      <CommandPalette files={files} />
    </>
  )
}
