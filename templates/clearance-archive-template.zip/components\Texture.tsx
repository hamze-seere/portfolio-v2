'use client'

import { useEffect } from 'react'

/*
  Generates the two print textures once on a canvas and hands them to CSS:
  halftone dots + photocopy grain for paper, fine fibre grain for the vellum console.
  No gradients — just pixels.
*/
function tile(size: number, paint: (ctx: CanvasRenderingContext2D, size: number) => void) {
  const c = document.createElement('canvas')
  c.width = c.height = size
  const ctx = c.getContext('2d')!
  paint(ctx, size)
  return c.toDataURL('image/png')
}

function grain(ctx: CanvasRenderingContext2D, size: number, rgb: string, density: number, alpha: number) {
  const img = ctx.getImageData(0, 0, size, size)
  const [r, g, b] = rgb.split(',').map(Number)
  for (let i = 0; i < img.data.length; i += 4) {
    if (Math.random() > density) continue
    img.data[i] = r
    img.data[i + 1] = g
    img.data[i + 2] = b
    img.data[i + 3] = Math.random() * alpha
  }
  ctx.putImageData(img, 0, 0)
}

export function Texture() {
  useEffect(() => {
    const paper = tile(192, (ctx, s) => {
      grain(ctx, s, '20,19,15', 0.22, 26)
      // Halftone: a rotated dot screen with jittered dot size, very faint.
      ctx.fillStyle = 'rgba(20,19,15,0.05)'
      const step = 6
      for (let y = -s; y < s * 2; y += step) {
        for (let x = -s; x < s * 2; x += step) {
          const rx = x * 0.966 - y * 0.259
          const ry = x * 0.259 + y * 0.966
          if (rx < 0 || ry < 0 || rx > s || ry > s) continue
          ctx.beginPath()
          ctx.arc(rx, ry, 0.5 + Math.random() * 0.7, 0, Math.PI * 2)
          ctx.fill()
        }
      }
    })
    const vellum = tile(160, (ctx, s) => {
      grain(ctx, s, '240,200,140', 0.35, 14)
      ctx.strokeStyle = 'rgba(240,200,140,0.025)'
      for (let i = 0; i < 40; i++) {
        ctx.beginPath()
        const x = Math.random() * s
        const y = Math.random() * s
        ctx.moveTo(x, y)
        ctx.lineTo(x + (Math.random() - 0.5) * 30, y + (Math.random() - 0.5) * 6)
        ctx.stroke()
      }
    })
    const root = document.documentElement.style
    root.setProperty('--tex-paper', `url(${paper})`)
    root.setProperty('--tex-vellum', `url(${vellum})`)
  }, [])
  return null
}
