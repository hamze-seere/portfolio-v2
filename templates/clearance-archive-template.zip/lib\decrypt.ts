'use client'

import { useContext, useEffect, useLayoutEffect, useRef, createContext } from 'react'
import { decryptActive, decryptProgress, decryptRegister } from './store'

/* ─────────────────────────────────────────────────────────────
   Glyph decryption. One shared requestAnimationFrame loop drives
   every active job and writes textContent directly — no React
   state per character, no library.
   Glyph set is ASCII/Latin-1 only so every glyph exists in the
   three loaded faces (no fallback font sneaks in mid-scramble).
   ───────────────────────────────────────────────────────────── */

const GLYPHS = '0123456789ABCDEF#$%&*+/<=>?@[]{}|~§¶'
const STEP_MS = 18
const MAX_MS = 1400 // long paragraphs compress their stagger to stay under this

type Job = {
  el: HTMLElement
  text: string
  start: number
  step: number
  resolved: number
  done: () => void
}

const jobs = new Set<Job>()
let raf = 0
let frame = 0

const glyph = () => GLYPHS[(Math.random() * GLYPHS.length) | 0]

export function scramble(text: string, from = 0) {
  let out = text.slice(0, from)
  for (let i = from; i < text.length; i++) {
    const c = text[i]
    out += c === ' ' || c === '\n' ? c : glyph()
  }
  return out
}

function finish(job: Job) {
  const { el, text } = job
  el.textContent = text.slice(0, -1)
  const lock = document.createElement('span')
  lock.className = 'dc-lock'
  lock.textContent = text.slice(-1)
  el.appendChild(lock)
  el.dataset.state = 'done'
  jobs.delete(job)
  job.done()
}

function tick(now: number) {
  frame++
  let progressed = 0
  for (const job of jobs) {
    const t = now - job.start
    if (t < 0) continue
    const n = Math.min(job.text.length, Math.floor(t / job.step))
    progressed += n - job.resolved
    job.resolved = n
    if (n >= job.text.length) {
      finish(job)
      continue
    }
    // Re-roll unresolved glyphs every other frame — half the writes, same feel.
    if (frame % 2 === 0) job.el.textContent = scramble(job.text, n)
  }
  if (progressed) decryptProgress(progressed)
  raf = jobs.size ? requestAnimationFrame(tick) : 0
}

export function runDecrypt(el: HTMLElement, text: string, delay = 0): Promise<void> {
  return new Promise((resolve) => {
    decryptActive(1)
    el.dataset.state = 'running'
    jobs.add({
      el,
      text,
      start: performance.now() + delay,
      step: Math.min(STEP_MS, MAX_MS / Math.max(1, text.length)),
      resolved: 0,
      done: () => {
        decryptActive(-1)
        resolve()
      },
    })
    if (!raf) raf = requestAnimationFrame(tick)
  })
}

export const prefersReduced = () =>
  typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches

/* ── Section gate: decryptions fire once per section, in order ── */

export type Gate = { active: boolean; claim: () => number }
export const GateContext = createContext<Gate | null>(null)

/**
 * Arms `ref` with scrambled glyphs before paint, then decrypts once its
 * section gate opens. Outside a gate (dossiers, notes) it runs on mount.
 */
export function useDecrypt(ref: React.RefObject<HTMLElement | null>, text: string) {
  const gate = useContext(GateContext)
  const order = useRef<number>(-1)
  const started = useRef(false)
  const registered = useRef(false)

  useLayoutEffect(() => {
    const el = ref.current
    if (!el) return
    if (order.current < 0) order.current = gate ? gate.claim() : 0
    if (prefersReduced()) {
      el.textContent = text
      el.dataset.state = 'fade'
      return
    }
    el.textContent = scramble(text)
    el.dataset.state = 'armed'
    if (!registered.current) decryptRegister(text.length)
    registered.current = true
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [text])

  const active = gate ? gate.active : true
  useEffect(() => {
    const el = ref.current
    if (!el || !active || started.current) return
    started.current = true
    if (el.dataset.state === 'fade') {
      el.dataset.state = 'shown'
      return
    }
    runDecrypt(el, text, Math.min(order.current, 12) * 70)
  }, [active, text, ref])
}
