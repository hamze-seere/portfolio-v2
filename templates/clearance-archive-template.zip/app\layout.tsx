import type { Metadata, Viewport } from 'next'
import { headers } from 'next/headers'
import { Archivo, Instrument_Serif, JetBrains_Mono } from 'next/font/google'
import './globals.css'

/*
  Exactly three faces, self-hosted at build time by next/font (no third-party
  font request, so nothing to SRI-pin at runtime):
  1. Archivo, condensed via its wdth axis → headings
  2. JetBrains Mono → console, metadata, labels, body
  3. Instrument Serif → dossier titles only
*/
const display = Archivo({ subsets: ['latin'], axes: ['wdth'], variable: '--f-display', display: 'swap' })
const mono = JetBrains_Mono({ subsets: ['latin'], variable: '--f-mono', display: 'swap' })
const serif = Instrument_Serif({ subsets: ['latin'], weight: '400', variable: '--f-serif', display: 'swap' })

export const metadata: Metadata = {
  title: 'Personnel File — Security Engineer × Designer',
  description: 'A classified archive. Scroll to earn clearance.',
  robots: { index: true, follow: true },
  referrer: 'strict-origin-when-cross-origin',
}

export const viewport: Viewport = { themeColor: '#f2eee4', colorScheme: 'light' }

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const nonce = (await headers()).get('x-nonce') ?? undefined
  return (
    <html lang="en" className={`${display.variable} ${mono.variable} ${serif.variable}`}>
      <head>
        {/* Without JS, glyphs never arm — show the real text immediately. */}
        <noscript>
          <style nonce={nonce}>{'.dc{visibility:visible!important}'}</style>
        </noscript>
      </head>
      <body>
        {/* Blueprint probe warp — applied to plates while probed. */}
        <svg width="0" height="0" className="absolute" aria-hidden="true" focusable="false">
          <filter id="probe-warp" x="-5%" y="-5%" width="110%" height="110%">
            <feTurbulence type="fractalNoise" baseFrequency="0.004 0.09" numOctaves="1" seed="7" result="n" />
            <feDisplacementMap in="SourceGraphic" in2="n" scale="9" xChannelSelector="R" yChannelSelector="G" />
          </filter>
        </svg>
        {children}
      </body>
    </html>
  )
}
