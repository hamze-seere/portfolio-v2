'use client'

import { useActionState, useEffect, useRef, useState } from 'react'
import { motion } from 'framer-motion'
import { Decrypt } from './Decrypt'
import { Lock } from './Lock'
import { transmit } from '@/app/actions'
import { CHANNELS, validate, type Errors, type Fields, type TxState } from '@/lib/transmission'
import { log } from '@/lib/store'
import { site } from '@/content/site'

/*
  L5 — Secure channel. Real form, real validation (client + server), styled as
  an outgoing transmission. The payload fingerprint is a live SHA-256 of the
  message, computed locally with WebCrypto.
*/
async function sha256(text: string) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text))
  return Array.from(new Uint8Array(buf), (b) => b.toString(16).padStart(2, '0')).join('')
}

const EMPTY: Fields = { callsign: '', channel: '', subject: '', message: '' }

function Field({ id, label, error, children }: { id: keyof Fields; label: string; error?: string; children: React.ReactNode }) {
  return (
    <div className="border-b border-ink py-3">
      <label htmlFor={id} className="block font-mono text-[10px] uppercase tracking-[0.14em] text-ink-2">
        {label}
      </label>
      {children}
      <p id={`${id}-err`} className="min-h-[1.2em] font-mono text-[10px] tracking-[0.08em] text-signal" aria-live="polite">
        {error ? `✕ ${error}` : ''}
      </p>
    </div>
  )
}

export function Contact() {
  const [state, action, pending] = useActionState<TxState, FormData>(transmit, { status: 'idle' })
  const [fields, setFields] = useState(EMPTY)
  const [touched, setTouched] = useState<Partial<Record<keyof Fields, boolean>>>({})
  const [digest, setDigest] = useState('')
  const [openedAt, setOpenedAt] = useState('')
  const formRef = useRef<HTMLFormElement>(null)

  useEffect(() => setOpenedAt(String(Date.now())), [])

  useEffect(() => {
    let live = true
    if (!fields.message) return setDigest('')
    sha256(fields.message).then((h) => live && setDigest(h))
    return () => {
      live = false
    }
  }, [fields.message])

  useEffect(() => {
    if (state.status === 'sent') log(`› transmission accepted: ${state.ref}`, 'grant')
    if (state.status === 'error') log(`› transmission rejected${state.message ? ': ' + state.message.toLowerCase() : ' — validation'}`, 'warn')
  }, [state])

  const local = validate(fields)
  const server: Errors = state.status === 'error' ? state.errors : {}
  const err = (k: keyof Fields) => (touched[k] ? local[k] : undefined) ?? server[k]
  const set = (k: keyof Fields) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
    setFields((f) => ({ ...f, [k]: e.target.value }))
  const blur = (k: keyof Fields) => () => setTouched((t) => ({ ...t, [k]: true }))
  const aria = (k: keyof Fields) => ({ 'aria-invalid': !!err(k), 'aria-describedby': `${k}-err` })

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    setTouched({ callsign: true, channel: true, subject: true, message: true })
    if (Object.keys(local).length) {
      e.preventDefault()
      log('› transmission blocked client-side — fix highlighted fields', 'warn')
      const first = Object.keys(local)[0]
      formRef.current?.querySelector<HTMLElement>(`#${first}`)?.focus()
    }
  }

  const input = 'mt-1 w-full bg-transparent py-1 font-mono text-[15px] text-ink outline-none placeholder:text-ink-3 focus-visible:bg-paper-2'

  return (
    <>
      <h2 className="font-display text-[clamp(44px,6vw,88px)] uppercase leading-[0.86] text-ink">
        <Decrypt text="Request secure channel" />
      </h2>
      <p className="mt-4 max-w-[52ch] text-[17px] leading-relaxed text-ink-2">
        <Decrypt text="You have full clearance. This is the only door in the archive that opens all the way. Tell me what you are building — or what you need broken." />
      </p>

      {state.status === 'sent' ? (
        <div role="status" className="mt-12 border border-ink p-6">
          <div className="font-mono text-[11px] uppercase tracking-[0.14em] text-ink-2">Transmission accepted</div>
          <div className="mt-2 font-display text-[44px] uppercase leading-none text-ink">{state.ref}</div>
          <p className="mt-4 max-w-[48ch] text-[16px] text-ink-2">Delivered over TLS to a single inbox. No analytics saw it; no copy is kept on this server. Expect a reply within two working days.</p>
        </div>
      ) : (
        <form ref={formRef} action={action} onSubmit={onSubmit} noValidate className="mt-12 max-w-[680px] border-t border-ink">
          <input type="hidden" name="t" value={openedAt} />
          <div className="absolute -left-[9999px] h-px w-px overflow-hidden" aria-hidden="true">
            <label htmlFor="fax">Leave empty</label>
            <input id="fax" name="fax" tabIndex={-1} autoComplete="off" />
          </div>

          <Field id="callsign" label="01 / Callsign (name)" error={err('callsign')}>
            <input id="callsign" name="callsign" autoComplete="name" maxLength={80} className={input} value={fields.callsign} onChange={set('callsign')} onBlur={blur('callsign')} {...aria('callsign')} />
          </Field>
          <Field id="channel" label="02 / Return channel (email)" error={err('channel')}>
            <input id="channel" name="channel" type="email" autoComplete="email" inputMode="email" spellCheck={false} maxLength={320} className={input} value={fields.channel} onChange={set('channel')} onBlur={blur('channel')} {...aria('channel')} />
          </Field>
          <Field id="subject" label="03 / Transmission class" error={err('subject')}>
            <select id="subject" name="subject" className={`${input} appearance-none`} value={fields.subject} onChange={set('subject')} onBlur={blur('subject')} {...aria('subject')}>
              <option value="">— select —</option>
              {CHANNELS.map((c) => (
                <option key={c}>{c}</option>
              ))}
            </select>
          </Field>
          <Field id="message" label="04 / Payload" error={err('message')}>
            <textarea id="message" name="message" rows={6} maxLength={4000} className={`${input} resize-y leading-relaxed`} value={fields.message} onChange={set('message')} onBlur={blur('message')} {...aria('message')} />
            <div className="mt-1 flex justify-between gap-4 font-mono text-[10px] uppercase tracking-[0.08em] text-ink-3">
              <span className="truncate">sha-256 {digest ? `${digest.slice(0, 16)}…${digest.slice(-8)}` : '— awaiting payload —'}</span>
              <span className="shrink-0 tabular-nums">{fields.message.length}/4000</span>
            </div>
          </Field>

          {state.status === 'error' && state.message && (
            <p role="alert" className="mt-4 font-mono text-[11px] uppercase tracking-[0.1em] text-signal">
              ✕ {state.message}
            </p>
          )}

          <div className="mt-8 flex flex-wrap items-center gap-6">
            <motion.button
              type="submit"
              disabled={pending}
              className="cta flex items-center gap-3 border border-ink bg-ink px-5 py-3 font-mono text-[12px] uppercase tracking-[0.14em] text-paper disabled:opacity-60"
              initial="rest"
              whileHover="open"
              whileFocus="open"
              animate={pending ? 'open' : 'rest'}
              data-log="TRANSMIT"
            >
              <Lock full />
              {pending ? 'Encrypting…' : 'Transmit'}
            </motion.button>
            <span className="font-mono text-[10px] uppercase tracking-[0.1em] text-ink-3">
              Or plaintext: <a className="underline decoration-1 underline-offset-2 hover:text-ink" href={`mailto:${site.email}`}>{site.email}</a>
            </span>
          </div>
        </form>
      )}
    </>
  )
}
