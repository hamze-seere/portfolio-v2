'use client'

import { useEffect } from 'react'
import { live, log, logOnce, store } from '@/lib/store'

/* ─────────────────────────────────────────────────────────────
   Real signals → console. Everything logged here actually
   happened in this browser; nothing is scripted theater.
   Nothing leaves the page.
   ───────────────────────────────────────────────────────────── */

const IDLE_MS = 6000
let booted = false // StrictMode mounts effects twice in dev; boot the log once

export function Signals() {
  useEffect(() => {
    const mq = matchMedia('(prefers-reduced-motion: reduce)')
    const applyReduced = () => store.set({ reduced: mq.matches })
    applyReduced()
    mq.addEventListener('change', applyReduced)

    // Boot handshake — every value is read from the live environment.
    if (!booted) {
      booted = true
      const ref = document.referrer ? new URL(document.referrer).host : 'direct'
      log(`› session opened ${new Date().toISOString().slice(0, 19).replace('T', ' ')}Z`)
      log(`› transport: ${location.protocol === 'https:' ? 'TLS (https)' : 'PLAINTEXT (http) — dev only'}`, location.protocol === 'https:' ? 'plain' : 'warn')
      log(`› origin of approach: ${ref}`)
      log(`› viewport ${innerWidth}×${innerHeight} @${devicePixelRatio}x`)
      log(`› reduced motion: ${mq.matches ? 'requested — honoring' : 'not requested'}`, 'dim')
      log('› awaiting operator…', 'dim')
    }

    let idleTimer: ReturnType<typeof setTimeout>
    let tracked = false
    const wake = () => {
      clearTimeout(idleTimer)
      if (store.get().idle) {
        store.set({ idle: false })
        log('› operator resumed')
      }
      idleTimer = setTimeout(() => {
        store.set({ idle: true })
        log(`› idle ${IDLE_MS / 1000}s — pulse flatlined`, 'dim')
      }, IDLE_MS)
    }

    const onMove = (e: PointerEvent) => {
      live.cursorX = e.clientX
      live.cursorY = e.clientY
      if (!tracked) {
        tracked = true
        log('› cursor tracked')
      }
      wake()
    }

    const onOver = (e: PointerEvent) => {
      const el = (e.target as Element).closest?.('[data-log]')
      if (el) logOnce(`hover:${el.getAttribute('data-log')}`, `› hover: ${el.getAttribute('data-log')}`, 2500)
    }

    const onVis = () => log(document.hidden ? '› focus lost — tab hidden' : '› focus regained', document.hidden ? 'warn' : 'plain')
    const onCopy = () => {
      const n = (getSelection()?.toString() ?? '').length
      log(`› clipboard: ${n} chars exfiltrated`, 'warn')
    }
    const onPrint = () => log('› print job intercepted — rendering dossier', 'warn')
    const onResize = () => logOnce('resize', `› viewport ${innerWidth}×${innerHeight}`, 800, 'dim')

    addEventListener('pointermove', onMove, { passive: true })
    addEventListener('pointerover', onOver, { passive: true })
    addEventListener('keydown', wake)
    addEventListener('wheel', wake, { passive: true })
    addEventListener('touchstart', wake, { passive: true })
    document.addEventListener('visibilitychange', onVis)
    document.addEventListener('copy', onCopy)
    addEventListener('beforeprint', onPrint)
    addEventListener('resize', onResize)
    wake()

    return () => {
      clearTimeout(idleTimer)
      mq.removeEventListener('change', applyReduced)
      removeEventListener('pointermove', onMove)
      removeEventListener('pointerover', onOver)
      removeEventListener('keydown', wake)
      removeEventListener('wheel', wake)
      removeEventListener('touchstart', wake)
      document.removeEventListener('visibilitychange', onVis)
      document.removeEventListener('copy', onCopy)
      removeEventListener('beforeprint', onPrint)
      removeEventListener('resize', onResize)
    }
  }, [])

  return null
}
