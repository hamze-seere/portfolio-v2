'use client'

import { useEffect, useState } from 'react'
import { log, useStore } from '@/lib/store'

/*
  Footer + security badge. The badge doesn't take our word for it: it re-requests
  this page and checks the response headers the browser actually received.
*/
const REQUIRED = [
  ['content-security-policy', 'CSP'],
  ['strict-transport-security', 'HSTS'],
  ['x-content-type-options', 'XCTO'],
  ['x-frame-options', 'XFO'],
  ['referrer-policy', 'Referrer'],
  ['permissions-policy', 'Permissions'],
  ['cross-origin-opener-policy', 'COOP'],
] as const

export function Footer() {
  const granted = useStore((s) => s.granted)
  const [check, setCheck] = useState<{ ok: string[]; missing: string[]; strict: boolean } | null>(null)
  const [host, setHost] = useState('')

  useEffect(() => {
    setHost(location.host)
    fetch(location.pathname, { method: 'HEAD', cache: 'no-store', credentials: 'omit' })
      .then((r) => {
        const ok: string[] = []
        const missing: string[] = []
        for (const [h, label] of REQUIRED) (r.headers.get(h) ? ok : missing).push(label)
        const csp = r.headers.get('content-security-policy') ?? ''
        const strict = csp.includes("'strict-dynamic'") && !/script-src[^;]*'unsafe-inline'/.test(csp)
        setCheck({ ok, missing, strict })
        log(`› self-audit: ${ok.length}/${REQUIRED.length} hardening headers present${strict ? ', nonce CSP' : ''}`, missing.length ? 'warn' : 'plain')
      })
      .catch(() => setCheck({ ok: [], missing: REQUIRED.map((r) => r[1]), strict: false }))
  }, [])

  return (
    <footer id="archive-footer" className="border-t border-ink px-[clamp(20px,5vw,72px)] pb-16 pt-10">
      <div className="flex flex-wrap items-start justify-between gap-8">
        <div>
          <div className="font-mono text-[11px] uppercase tracking-[0.14em] text-ink-2">End of archive</div>
          <p className="mt-2 font-display text-[28px] uppercase leading-none text-ink">
            {granted >= 5 ? 'Level 5 clearance granted — welcome, archivist.' : 'Clearance pending.'}
          </p>
        </div>

        <div className="badge border border-ink p-3 font-mono text-[10px] uppercase tracking-[0.1em]">
          <div className="flex items-center gap-2 text-ink">
            <span className="bg-ink px-1 text-paper">A+</span> this site: A+ security headers
          </div>
          <div className="mt-2 text-ink-2">
            {check === null
              ? 'Self-audit running…'
              : check.missing.length
                ? `Self-audit: missing ${check.missing.join(', ')}`
                : `Self-audit: ${check.ok.length}/${REQUIRED.length} verified in this response${check.strict ? ' · nonce CSP' : ''}`}
          </div>
          <div className="mt-1 text-ink-3">No trackers · no third-party requests · self-hosted fonts</div>
          {host && (
            <a
              className="mt-2 inline-block text-blueprint underline decoration-1 underline-offset-2"
              href={`https://securityheaders.com/?q=${encodeURIComponent(host)}&followRedirects=on`}
              target="_blank"
              rel="noopener noreferrer"
            >
              Verify independently ↗
            </a>
          )}
        </div>
      </div>
      <div className="mt-10 flex flex-wrap justify-between gap-4 font-mono text-[10px] uppercase tracking-[0.12em] text-ink-3">
        <span>© {new Date().getFullYear()} — all files remain the property of their authors</span>
        <button className="underline decoration-1 underline-offset-2 hover:text-ink" onClick={() => window.print()}>
          Print as dossier
        </button>
      </div>
    </footer>
  )
}
