'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { clearLog, lockScroll, log, openDossier, scrollToLevel, store } from '@/lib/store'

/*
  ⌘K — query the archive. Fuzzy search over files plus slash commands,
  keyboard-first: ↑↓ to move, ↵ to run, Esc to close.
*/
export type Entry = { id: string; label: string; hint: string; run: () => void }

function score(q: string, s: string) {
  if (!q) return 1
  q = q.toLowerCase()
  s = s.toLowerCase()
  if (s.includes(q)) return 100 - s.indexOf(q)
  let i = 0
  let gaps = 0
  for (const c of s) {
    if (c === q[i]) i++
    else if (i) gaps++
    if (i === q.length) return 50 - gaps
  }
  return -1
}

export function CommandPalette({ files }: { files: { kind: string; slug: string; code: string; title: string }[] }) {
  const [open, setOpen] = useState(false)
  const [q, setQ] = useState('')
  const [idx, setIdx] = useState(0)
  const input = useRef<HTMLInputElement>(null)
  const returnTo = useRef<Element | null>(null)

  const entries = useMemo<Entry[]>(() => {
    const cmds: Entry[] = [
      { id: '/identity', label: '/identity', hint: 'jump to L1', run: () => scrollToLevel(1) },
      { id: '/projects', label: '/projects', hint: 'jump to L2 — selected work', run: () => scrollToLevel(2) },
      { id: '/capabilities', label: '/capabilities', hint: 'jump to L3', run: () => scrollToLevel(3) },
      { id: '/notes', label: '/notes', hint: 'jump to L4 — declassified', run: () => scrollToLevel(4) },
      { id: '/contact', label: '/contact', hint: 'jump to L5 — secure channel', run: () => scrollToLevel(5) },
      {
        id: '/redacted',
        label: '/redacted',
        hint: 'burn every redaction',
        run: () => {
          store.set({ burnAll: true })
          log('› /redacted — all redactions burned by operator', 'warn')
        },
      },
      { id: '/clear', label: '/clear', hint: 'clear the console log', run: clearLog },
      { id: '/print', label: '/print', hint: 'print the archive as a dossier', run: () => setTimeout(() => window.print(), 50) },
    ]
    const docs: Entry[] = files.map((f) => ({
      id: `${f.kind}:${f.slug}`,
      label: f.title,
      hint: f.code,
      run: () => {
        scrollToLevel(f.kind === 'project' ? 2 : 4, true)
        requestAnimationFrame(() => openDossier(f.kind, f.slug))
      },
    }))
    return [...cmds, ...docs]
  }, [files])

  const results = useMemo(() => {
    const term = q.trim()
    const pool = term.startsWith('/') ? entries.filter((e) => e.id.startsWith('/')) : entries
    return pool
      .map((e) => ({ e, s: Math.max(score(term, e.label), score(term, e.hint) - 10) }))
      .filter((r) => r.s >= 0)
      .sort((a, b) => b.s - a.s)
      .slice(0, 9)
      .map((r) => r.e)
  }, [q, entries])

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const typing = (e.target as Element).closest?.('input,textarea,select,[contenteditable]')
      if ((e.key === 'k' && (e.metaKey || e.ctrlKey)) || (e.key === '/' && !typing && !open)) {
        e.preventDefault()
        setOpen((o) => !o)
      }
    }
    addEventListener('keydown', onKey)
    return () => removeEventListener('keydown', onKey)
  }, [open])

  useEffect(() => {
    store.set({ paletteOpen: open })
    if (open) {
      returnTo.current = document.activeElement
      lockScroll(true)
      log('› archive query opened')
      setQ('')
      setIdx(0)
      requestAnimationFrame(() => input.current?.focus())
    } else if (returnTo.current) {
      lockScroll(false)
      ;(returnTo.current as HTMLElement).focus?.()
      returnTo.current = null
    }
  }, [open])

  const run = (e: Entry | undefined) => {
    if (!e) {
      log(`› query: "${q}" — no match in archive`, 'dim')
      return
    }
    setOpen(false)
    log(`› query: ${e.id.startsWith('/') ? e.id : e.hint}`)
    e.run()
  }

  return (
    <AnimatePresence>
      {open && (
        <motion.div className="fixed inset-0 z-[65] flex items-start justify-center px-4 pt-[14vh]" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.12 }}>
          <div className="absolute inset-0 bg-ink/50" onClick={() => setOpen(false)} aria-hidden="true" />
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label="Query the archive"
            className="tex-vellum relative w-full max-w-[620px] border border-amber-dim bg-console font-mono text-amber"
            initial={{ y: -8 }}
            animate={{ y: 0 }}
            transition={{ type: 'spring', stiffness: 700, damping: 40 }}
          >
            <div className="flex items-center gap-2 border-b border-amber-line px-4 py-3 text-[14px]">
              <span className="text-amber-dim" aria-hidden="true">archive&gt;</span>
              <input
                ref={input}
                value={q}
                onChange={(e) => {
                  setQ(e.target.value)
                  setIdx(0)
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Escape') setOpen(false)
                  if (e.key === 'ArrowDown') (e.preventDefault(), setIdx((i) => Math.min(results.length - 1, i + 1)))
                  if (e.key === 'ArrowUp') (e.preventDefault(), setIdx((i) => Math.max(0, i - 1)))
                  if (e.key === 'Enter') run(results[idx])
                  if (e.key === 'Tab') e.preventDefault()
                }}
                role="combobox"
                aria-expanded="true"
                aria-controls="palette-list"
                aria-activedescendant={results[idx] ? `opt-${idx}` : undefined}
                aria-autocomplete="list"
                spellCheck={false}
                autoComplete="off"
                placeholder="search files or type / for commands"
                className="flex-1 bg-transparent text-amber caret-amber outline-none placeholder:text-amber-dim"
              />
              <kbd className="text-[10px] text-amber-dim">ESC</kbd>
            </div>
            <ul id="palette-list" role="listbox" className="max-h-[50vh] overflow-y-auto py-1 text-[12px]" data-lenis-prevent>
              {results.length === 0 && <li className="px-4 py-3 text-amber-dim">no match — the archive is not that large</li>}
              {results.map((r, i) => (
                <li
                  key={r.id}
                  id={`opt-${i}`}
                  role="option"
                  aria-selected={i === idx}
                  onPointerEnter={() => setIdx(i)}
                  onClick={() => run(r)}
                  className={`flex cursor-pointer justify-between gap-4 px-4 py-2 ${i === idx ? 'bg-amber text-console' : ''}`}
                >
                  <span>
                    <span aria-hidden="true">{i === idx ? '› ' : '  '}</span>
                    {r.label}
                  </span>
                  <span className={i === idx ? '' : 'text-amber-dim'}>{r.hint}</span>
                </li>
              ))}
            </ul>
            <div className="flex justify-between border-t border-amber-line px-4 py-2 text-[10px] uppercase tracking-[0.1em] text-amber-dim">
              <span>↑↓ select · ↵ run</span>
              <span>/projects /redacted /clear</span>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
