'use client'

import { useRef, type ElementType } from 'react'
import { useDecrypt } from '@/lib/decrypt'

type Props = { text: string; as?: ElementType; className?: string; id?: string }

/** Text that resolves from glyphs. The visual layer is aria-hidden; assistive tech reads the real text. */
export function Decrypt({ text, as: Tag = 'span', className, id }: Props) {
  const ref = useRef<HTMLSpanElement>(null)
  useDecrypt(ref, text)
  return (
    <Tag className={className} id={id}>
      <span ref={ref} className="dc" aria-hidden="true">
        {text}
      </span>
      <span className="sr-only">{text}</span>
    </Tag>
  )
}
