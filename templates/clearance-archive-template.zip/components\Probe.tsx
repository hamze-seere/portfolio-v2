'use client'

import { useEffect, useRef, useState } from 'react'
import { useStore, type CursorMode } from '@/lib/store'

/*
  Blueprint probe: drafting crosshair cursor with a live coordinate readout.
  States: crosshair (default) · lock-opening (link) · caliper (drag) ·
  spinning gear (decrypting) · dimming heartbeat (idle).
  Fine pointers only; touch keeps native behaviour.
*/
const LINKISH = 'a,button,[role="button"],summary,select,[data-cursor="link"]'

function Glyph({ mode }: { mode: CursorMode }) {
  switch (mode) {
    case 'link':
      return (
        <svg width="26" height="30" viewBox="0 0 26 30">
          <path className="probe-shackle" d="M7 14V9a6 6 0 0 1 12 0v5" fill="none" stroke="currentColor" strokeWidth="1.25" />
          <rect x="3.5" y="14" width="19" height="13" fill="currentColor" />
          <rect x="12" y="18" width="2" height="5" fill="var(--paper)" />
        </svg>
      )
    case 'drag':
      return (
        <svg width="38" height="30" viewBox="0 0 38 30">
          <path d="M4 3h30M4 3v24M34 3v24M4 27h6M28 27h6M10 15h18M10 12v6M28 12v6" fill="none" stroke="currentColor" strokeWidth="1.25" />
        </svg>
      )
    case 'decrypt':
      return (
        <svg width="30" height="30" viewBox="0 0 30 30" className="probe-spin">
          <path
            d="M13 2h4l.7 3.4 2.6 1.1 2.9-1.9 2.8 2.8-1.9 2.9 1.1 2.6L28 13v4l-3.4.7-1.1 2.6 1.9 2.9-2.8 2.8-2.9-1.9-2.6 1.1L17 28h-4l-.7-3.4-2.6-1.1-2.9 1.9-2.8-2.8 1.9-2.9-1.1-2.6L2 17v-4l3.4-.7 1.1-2.6-1.9-2.9 2.8-2.8 2.9 1.9 2.6-1.1z"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.1"
          />
          <circle cx="15" cy="15" r="4" fill="none" stroke="currentColor" strokeWidth="1.1" />
        </svg>
      )
    case 'idle':
      return (
        <svg width="40" height="20" viewBox="0 0 40 20" className="probe-idle">
          <path d="M0 12h12l3-7 4 13 3-9 2 3h16" fill="none" stroke="currentColor" strokeWidth="1.1" />
        </svg>
      )
    default:
      return (
        <svg width="34" height="34" viewBox="0 0 34 34">
          <path d="M17 0v13M17 21v13M0 17h13M21 17h13" stroke="currentColor" strokeWidth="1" />
          <circle cx="17" cy="17" r="5.5" fill="none" stroke="currentColor" strokeWidth="1" />
        </svg>
      )
  }
}

export function Probe() {
  const dot = useRef<HTMLDivElement>(null)
  const hx = useRef<HTMLDivElement>(null)
  const vy = useRef<HTMLDivElement>(null)
  const coords = useRef<HTMLSpanElement>(null)
  const [enabled, setEnabled] = useState(false)
  const [overLink, setOverLink] = useState(false)
  const [overField, setOverField] = useState(false)
  const dragging = useStore((s) => s.dragging)
  const decrypting = useStore((s) => s.decrypting > 0)
  const idle = useStore((s) => s.idle)

  useEffect(() => {
    const fine = matchMedia('(pointer: fine)')
    const apply = () => {
      setEnabled(fine.matches)
      document.documentElement.classList.toggle('has-probe', fine.matches)
    }
    apply()
    fine.addEventListener('change', apply)

    let raf = 0
    const move = (e: PointerEvent) => {
      const t = e.target as Element
      setOverLink(!!t.closest?.(LINKISH))
      setOverField(!!t.closest?.('input,textarea'))
      cancelAnimationFrame(raf)
      raf = requestAnimationFrame(() => {
        const x = Math.round(e.clientX)
        const y = Math.round(e.clientY)
        if (dot.current) dot.current.style.transform = `translate3d(${x}px,${y}px,0)`
        if (hx.current) hx.current.style.transform = `translate3d(0,${y}px,0)`
        if (vy.current) vy.current.style.transform = `translate3d(${x}px,0,0)`
        if (coords.current) coords.current.textContent = `X ${String(x).padStart(4, '0')} · Y ${String(y).padStart(4, '0')}`
      })
    }
    addEventListener('pointermove', move, { passive: true })
    return () => {
      fine.removeEventListener('change', apply)
      removeEventListener('pointermove', move)
      cancelAnimationFrame(raf)
    }
  }, [])

  if (!enabled) return null

  const mode: CursorMode = dragging ? 'drag' : overLink ? 'link' : decrypting ? 'decrypt' : idle ? 'idle' : 'probe'

  return (
    <div className="probe pointer-events-none fixed inset-0 z-[70]" aria-hidden="true" data-mode={mode}>
      <div ref={hx} className="absolute left-0 right-0 top-0 h-px bg-blueprint opacity-[0.16]" />
      <div ref={vy} className="absolute bottom-0 left-0 top-0 w-px bg-blueprint opacity-[0.16]" />
      <div ref={dot} className="absolute left-0 top-0" style={{ opacity: overField ? 0 : 1 }}>
        <div className="probe-glyph -translate-x-1/2 -translate-y-1/2">
          <Glyph mode={mode} />
        </div>
      </div>
      <span ref={coords} className="absolute bottom-3 right-4 bg-paper px-1 font-mono text-[10px] tracking-[0.12em] text-blueprint">
        X 0000 · Y 0000
      </span>
    </div>
  )
}
