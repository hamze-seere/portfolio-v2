# Clearance Archive

Portfolio as a classified archive. Next.js 16 (App Router) · Tailwind 4 · Framer Motion · GSAP ScrollTrigger · Lenis · MDX.

```
npm install
npm run dev        # http://localhost:3000
npm run build && npm start
```

## Edit content
- `content/site.ts` — name, thesis, projects, notes, capabilities (**sample content — replace**)
- `content/projects/*.mdx`, `content/notes/*.mdx` — dossier bodies (`omega.mdx` is the hidden file)
- `public/plates/*.svg` — figure plates (regenerate with `node scripts/plates.js`)

## Contact delivery
Set `CONTACT_WEBHOOK_URL` (Resend/Slack/n8n/etc). Without it, production refuses to send; dev logs to the server console. Rate limit is in-memory — use KV/Redis when running more than one instance.

## Security
- `proxy.ts` — per-request nonce CSP with `strict-dynamic`, no `unsafe-inline` scripts
- `next.config.mjs` — HSTS, XCTO, XFO, Referrer, Permissions, COOP, CORP
- Fonts self-hosted by `next/font` (no third-party requests)
- Footer badge re-fetches the page and verifies the headers live

Trade-off: a nonce CSP requires dynamic rendering, so the page is not ISR/static.
