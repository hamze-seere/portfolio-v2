'use client'

import { useSyncExternalStore } from 'react'

/* ─────────────────────────────────────────────────────────────
   Clearance store. One tiny external store drives the console,
   ladder, cursor and flash. High-frequency signals (velocity,
   cursor position) live in `live` and are read inside rAF loops,
   never pushed through React.
   ───────────────────────────────────────────────────────────── */

export const LEVELS = [
  { n: 1, id: 'identity', code: 'IDENTITY', klass: 'UNCLASSIFIED' },
  { n: 2, id: 'work', code: 'SELECTED_WORK', klass: 'RESTRICTED' },
  { n: 3, id: 'capabilities', code: 'CAPABILITIES', klass: 'CONFIDENTIAL' },
  { n: 4, id: 'notes', code: 'NOTES', klass: 'SECRET' },
  { n: 5, id: 'contact', code: 'SECURE_CHANNEL', klass: 'TOP SECRET' },
] as const

export type Tone = 'plain' | 'grant' | 'warn' | 'dim'
export type LogLine = { id: number; at: number; text: string; tone: Tone }
export type CursorMode = 'probe' | 'link' | 'drag' | 'decrypt' | 'idle'

export type State = {
  level: number // section currently in view
  granted: number // highest clearance earned
  viewed: number[]
  depth: number // max scroll depth, 0–100
  decryptTotal: number
  decryptDone: number
  decrypting: number // active decrypt jobs
  idle: boolean
  dragging: boolean
  reduced: boolean
  burnAll: boolean
  paletteOpen: boolean
  flash: number // increments on each grant; flash component keys off it
  log: LogLine[]
}

let state: State = {
  level: 1,
  granted: 0,
  viewed: [],
  depth: 0,
  decryptTotal: 0,
  decryptDone: 0,
  decrypting: 0,
  idle: false,
  dragging: false,
  reduced: false,
  burnAll: false,
  paletteOpen: false,
  flash: 0,
  log: [],
}

export const live = {
  velocity: 0,
  cursorX: 0,
  cursorY: 0,
  scroll: 0,
  startedAt: typeof performance !== 'undefined' ? performance.now() : 0,
}

const listeners = new Set<() => void>()
const emit = () => listeners.forEach((l) => l())

export const store = {
  get: () => state,
  set(patch: Partial<State> | ((s: State) => Partial<State>)) {
    const next = typeof patch === 'function' ? patch(state) : patch
    state = { ...state, ...next }
    emit()
  },
  subscribe(fn: () => void) {
    listeners.add(fn)
    return () => {
      listeners.delete(fn)
    }
  },
}

export function useStore<T>(select: (s: State) => T): T {
  return useSyncExternalStore(
    store.subscribe,
    () => select(state),
    () => select(state),
  )
}

/* ── Event log: lines append one-by-one at 30ms ─────────────── */

const MAX_LINES = 90
const pending: Omit<LogLine, 'id'>[] = []
let lineId = 0
let drain: ReturnType<typeof setInterval> | null = null

function flushOne() {
  const next = pending.shift()
  if (!next) {
    if (drain) clearInterval(drain)
    drain = null
    return
  }
  store.set((s) => ({ log: [...s.log, { ...next, id: ++lineId }].slice(-MAX_LINES) }))
}

export function log(text: string, tone: Tone = 'plain') {
  const line = { at: performance.now(), text, tone }
  if (state.reduced) {
    store.set((s) => ({ log: [...s.log, { ...line, id: ++lineId }].slice(-MAX_LINES) }))
    return
  }
  pending.push(line)
  if (pending.length > 40) pending.splice(0, pending.length - 40)
  if (!drain) drain = setInterval(flushOne, 30)
}

export function clearLog() {
  pending.length = 0
  store.set({ log: [] })
  log('› console cleared by operator', 'dim')
}

/* Throttle per key so hover/scroll chatter stays legible. */
const lastByKey = new Map<string, number>()
export function logOnce(key: string, text: string, every = 1200, tone: Tone = 'plain') {
  const now = performance.now()
  if (now - (lastByKey.get(key) ?? -Infinity) < every) return
  lastByKey.set(key, now)
  log(text, tone)
}

/* ── Clearance ──────────────────────────────────────────────── */

export function enterLevel(n: number) {
  const s = state
  const patch: Partial<State> = { level: n }
  if (!s.viewed.includes(n)) {
    patch.viewed = [...s.viewed, n].sort()
    log(`› section viewed: L${n}/${LEVELS[n - 1].code}`)
  }
  store.set(patch)
}

export function grantLevel(n: number) {
  if (n <= state.granted) return
  // Clearance is earned in order — skipping ahead grants each level in turn.
  for (let k = state.granted + 1; k <= n; k++) {
    if (k === 5) log('LEVEL 5 CLEARANCE GRANTED — welcome, archivist.', 'grant')
    else log(`CLEARANCE: L${k} GRANTED.`, 'grant')
  }
  store.set((s) => ({ granted: n, flash: s.flash + 1 }))
}

/* ── Decryption accounting ──────────────────────────────────── */

let lastDecile = -1
export function decryptRegister(chars: number) {
  store.set((s) => ({ decryptTotal: s.decryptTotal + chars }))
}
export function decryptProgress(chars: number) {
  store.set((s) => ({ decryptDone: Math.min(s.decryptTotal, s.decryptDone + chars) }))
  const { decryptDone, decryptTotal } = state
  const pct = decryptTotal ? Math.floor((decryptDone / decryptTotal) * 100) : 0
  const decile = Math.floor(pct / 10)
  if (decile !== lastDecile) {
    lastDecile = decile
    log(`› decryption: ${pct}%`, 'dim')
  }
}
export function decryptActive(delta: 1 | -1) {
  store.set((s) => ({ decrypting: Math.max(0, s.decrypting + delta) }))
}

/* ── Scroll bridge: the document pane registers its scroller ── */

type Scroller = { toLevel: (n: number, immediate?: boolean) => void; stop: () => void; start: () => void }
let scroller: Scroller | null = null
export const registerScroller = (s: Scroller | null) => (scroller = s)
export const scrollToLevel = (n: number, immediate = false) => scroller?.toLevel(n, immediate)
export const lockScroll = (locked: boolean) => (locked ? scroller?.stop() : scroller?.start())

/* ── Dossier bridge: palette can open any project / note ────── */

type Opener = (slug: string) => void
const openers = new Map<string, Opener>()
export const registerOpener = (kind: string, fn: Opener) => {
  openers.set(kind, fn)
  return () => {
    openers.delete(kind)
  }
}
export const openDossier = (kind: string, slug: string) => openers.get(kind)?.(slug)
