'use client'

import { useEffect, useState } from 'react'
import { store, useStore } from '@/lib/store'

/** A single-frame verification flash over the document pane when clearance rises. */
export function GrantFlash() {
  const flash = useStore((s) => s.flash)
  const granted = useStore((s) => s.granted)
  const [on, setOn] = useState(false)

  useEffect(() => {
    if (!flash || store.get().reduced) return
    // ~2 frames. A timer, not rAF: rAF is paused in hidden tabs and the flash would stick.
    setOn(true)
    const t = setTimeout(() => setOn(false), 34)
    return () => {
      clearTimeout(t)
      setOn(false)
    }
  }, [flash])

  if (!on) return null
  return (
    <div className="grant-flash pointer-events-none fixed inset-0 z-40" aria-hidden="true">
      <div className="absolute inset-3 border border-signal" />
      <span className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 font-display text-[12vw] uppercase leading-none text-paper">
        L{granted} verified
      </span>
    </div>
  )
}
