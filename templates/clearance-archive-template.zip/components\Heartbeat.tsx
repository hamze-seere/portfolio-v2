'use client'

import { useEffect, useRef } from 'react'
import { live, store } from '@/lib/store'

/* ─────────────────────────────────────────────────────────────
   Hairline heartbeat. Beat rate follows real scroll velocity:
   fast scroll → faster beat, idle → flatline. Canvas, one path,
   redrawn per frame from a ring buffer.
   ───────────────────────────────────────────────────────────── */

const SWEEP = 70 // px per second
const BEAT_W = 48 // px a single complex occupies

// One beat as a function of phase 0..1 (P wave, QRS complex, T wave)
function ecg(p: number) {
  const bump = (c: number, w: number, h: number) => h * Math.exp(-((p - c) ** 2) / (2 * w * w))
  return bump(0.12, 0.025, 0.12) - bump(0.24, 0.008, 0.18) + bump(0.27, 0.01, 1) - bump(0.3, 0.01, 0.32) + bump(0.52, 0.045, 0.22)
}

export function Heartbeat() {
  const canvas = useRef<HTMLCanvasElement>(null)
  const readout = useRef<HTMLSpanElement>(null)

  useEffect(() => {
    const c = canvas.current!
    const ctx = c.getContext('2d')!
    const ink = getComputedStyle(c).getPropertyValue('--amber').trim() || '#e2a23b'
    let w = 0
    let h = 0
    let buf: number[] = []
    const dpr = Math.min(2, window.devicePixelRatio || 1)

    const resize = () => {
      w = c.clientWidth
      h = c.clientHeight
      c.width = w * dpr
      c.height = h * dpr
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      buf = new Array(Math.ceil(w)).fill(0)
    }
    resize()
    const ro = new ResizeObserver(resize)
    ro.observe(c)

    const draw = () => {
      ctx.clearRect(0, 0, w, h)
      ctx.strokeStyle = ink
      ctx.lineWidth = 1
      ctx.beginPath()
      const mid = h * 0.62
      for (let x = 0; x < buf.length; x++) {
        const y = mid - buf[x] * h * 0.5
        if (x === 0) ctx.moveTo(x + 0.5, y)
        else ctx.lineTo(x + 0.5, y)
      }
      ctx.stroke()
      // write head
      ctx.fillStyle = ink
      ctx.fillRect(buf.length - 2, mid - buf[buf.length - 1] * h * 0.5 - 1.5, 3, 3)
    }

    if (store.get().reduced) {
      // Frozen: one static beat, centered.
      for (let x = 0; x < buf.length; x++) {
        const p = (x - buf.length * 0.4) / 90
        buf[x] = p > 0 && p < 1 ? ecg(p) : 0
      }
      draw()
      if (readout.current) readout.current.textContent = 'STATIC'
      return () => ro.disconnect()
    }

    let raf = 0
    let last = performance.now()
    let since = BEAT_W
    let vel = 0
    let bpm = 0
    let carry = 0
    let lastText = ''

    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000)
      last = now
      // Smooth velocity, decay toward zero when the pane is still.
      vel += (Math.abs(live.velocity) - vel) * Math.min(1, dt * 4)
      live.velocity *= 0.9
      const target = vel < 0.15 ? 0 : Math.min(180, 54 + vel * 1.8)
      bpm += (target - bpm) * Math.min(1, dt * 2)

      carry += SWEEP * dt
      const steps = Math.floor(carry)
      carry -= steps
      for (let i = 0; i < steps; i++) {
        since++
        // A new beat starts only while there is a pulse; its period shrinks as bpm rises.
        if (bpm > 20 && since >= (SWEEP * 60) / bpm) since = 0
        const noise = (Math.random() - 0.5) * 0.012
        buf.push(since < BEAT_W ? ecg(since / BEAT_W) * Math.min(1, bpm / 70) + noise : noise)
        buf.shift()
      }
      draw()

      const text = bpm < 20 ? 'FLATLINE' : `${Math.round(bpm)} BPM`
      if (text !== lastText && readout.current) readout.current.textContent = lastText = text
      raf = requestAnimationFrame(loop)
    }
    raf = requestAnimationFrame(loop)
    return () => {
      cancelAnimationFrame(raf)
      ro.disconnect()
    }
  }, [])

  return (
    <div className="relative">
      <div className="mb-1 flex justify-between font-mono text-[10px] uppercase tracking-[0.14em] text-amber-dim">
        <span>Scroll rhythm</span>
        <span ref={readout} className="text-amber">FLATLINE</span>
      </div>
      <canvas ref={canvas} className="block h-14 w-full" aria-hidden="true" />
    </div>
  )
}
