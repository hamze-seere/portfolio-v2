'use client'

import { useEffect, useRef, useState } from 'react'
import { Heartbeat } from './Heartbeat'
import { LEVELS, live, store, useStore } from '@/lib/store'

const pad = (n: number, w = 2) => String(Math.floor(n)).padStart(w, '0')
const clock = (ms: number) => {
  const s = ms / 1000
  return `${pad(s / 3600)}:${pad((s / 60) % 60)}:${pad(s % 60)}`
}

function Readout({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-baseline justify-between gap-3 border-b border-amber-line py-[5px]">
      <dt className="text-amber-dim">{label}</dt>
      <dd className="tabular-nums text-amber">{children}</dd>
    </div>
  )
}

export function Console() {
  const level = useStore((s) => s.level)
  const granted = useStore((s) => s.granted)
  const viewed = useStore((s) => s.viewed.length)
  const depth = useStore((s) => s.depth)
  const done = useStore((s) => s.decryptDone)
  const total = useStore((s) => s.decryptTotal)
  const lines = useStore((s) => s.log)
  const reduced = useStore((s) => s.reduced)
  const [elapsed, setElapsed] = useState(0)
  const [grantMsg, setGrantMsg] = useState('')
  const cursorRef = useRef<HTMLSpanElement>(null)
  const viewportRef = useRef<HTMLSpanElement>(null)
  const logRef = useRef<HTMLOListElement>(null)

  // Real time-on-page.
  useEffect(() => {
    const tick = () => setElapsed(performance.now() - live.startedAt)
    tick()
    const id = setInterval(tick, 1000)
    return () => clearInterval(id)
  }, [])

  // Cursor + viewport readouts are written directly, not through React.
  useEffect(() => {
    let raf = 0
    let last = ''
    const loop = () => {
      const t = `${pad(live.cursorX, 4)},${pad(live.cursorY, 4)}`
      if (t !== last && cursorRef.current) cursorRef.current.textContent = last = t
      raf = requestAnimationFrame(loop)
    }
    const vp = () => viewportRef.current && (viewportRef.current.textContent = `${innerWidth}×${innerHeight}`)
    vp()
    addEventListener('resize', vp)
    raf = requestAnimationFrame(loop)
    return () => {
      cancelAnimationFrame(raf)
      removeEventListener('resize', vp)
    }
  }, [])

  useEffect(() => {
    const el = logRef.current
    if (el) el.scrollTop = el.scrollHeight
  }, [lines])

  // Grants are announced to screen readers; the chatter is not.
  useEffect(() => {
    if (!granted) return
    setGrantMsg(granted === 5 ? 'Level 5 clearance granted. Welcome, archivist.' : `Clearance level ${granted} granted.`)
  }, [granted])

  const meta = LEVELS[level - 1]
  const pct = total ? Math.round((done / total) * 100) : 0

  return (
    <aside
      aria-label="Clearance console"
      className="console tex-vellum relative flex h-full min-h-0 flex-col overflow-hidden bg-console font-mono text-[11px] uppercase tracking-[0.08em] text-amber"
    >
      <div className="flex items-center justify-between border-b border-amber-line px-5 py-3">
        <span className="text-amber-dim">Clearance console</span>
        <span className="flex items-center gap-2">
          <span className={`inline-block h-[6px] w-[6px] bg-amber ${reduced ? '' : 'rec-blink'}`} aria-hidden="true" />
          {reduced ? 'STATIC' : 'LIVE'}
        </span>
      </div>

      <div className="border-b border-amber-line px-5 pb-4 pt-5">
        <div className="text-amber-dim">Access level</div>
        <div className="mt-1 flex items-end gap-4">
          <span className="font-display text-[clamp(56px,7vw,96px)] leading-[0.8] text-amber">L{level}</span>
          <span className="pb-1 leading-tight">
            {meta.klass}
            <br />
            <span className="text-amber-dim">{meta.code}</span>
          </span>
        </div>
        <ol className="mt-4 grid grid-cols-5 gap-1" aria-label={`Clearance granted: ${granted} of 5`}>
          {LEVELS.map((l) => (
            <li
              key={l.n}
              className={`h-[3px] ${l.n <= granted ? 'bg-amber' : 'bg-amber-line'}`}
              title={`L${l.n} ${l.klass}`}
            />
          ))}
        </ol>
      </div>

      <dl className="c-meta px-5 py-3">
        <Readout label="Session">{clock(elapsed)}</Readout>
        <Readout label="Scroll depth">{pad(depth, 3)}%</Readout>
        <Readout label="Sections viewed">{viewed}/5</Readout>
        <Readout label="Decrypted">
          {pad(pct, 3)}% <span className="text-amber-dim">({done}/{total} gl)</span>
        </Readout>
        <Readout label="Cursor">
          <span ref={cursorRef}>0000,0000</span>
        </Readout>
        <Readout label="Viewport">
          <span ref={viewportRef}>—</span>
        </Readout>
      </dl>

      <div className="c-pulse px-5 pb-3">
        <Heartbeat />
      </div>

      <div className="flex min-h-0 flex-1 flex-col border-t border-amber-line">
        <div className="flex justify-between px-5 py-2 text-amber-dim">
          <span>Event log</span>
          <span>{lines.length.toString().padStart(3, '0')} ev</span>
        </div>
        <ol
          ref={logRef}
          role="log"
          aria-live="off"
          aria-label="Session event log"
          className="console-log min-h-0 flex-1 overflow-y-auto px-5 pb-4 normal-case tracking-normal"
        >
          {lines.map((l) => (
            <li
              key={l.id}
              className={
                l.tone === 'grant'
                  ? 'my-1 bg-amber px-1 uppercase tracking-[0.08em] text-console'
                  : l.tone === 'warn'
                    ? 'text-signal-soft'
                    : l.tone === 'dim'
                      ? 'text-amber-dim'
                      : ''
              }
            >
              <span className="mr-2 text-amber-dim">{clock(l.at - live.startedAt).slice(3)}</span>
              {l.text}
            </li>
          ))}
        </ol>
      </div>

      <div className="c-foot flex justify-between border-t border-amber-line px-5 py-2 text-amber-dim">
        <span>
          <kbd className="text-amber">⌘K</kbd> / <kbd className="text-amber">Ctrl K</kbd> query the archive
        </span>
        <span>v1.0</span>
      </div>

      <p className="sr-only" role="status" aria-live="polite">
        {grantMsg}
      </p>
    </aside>
  )
}
