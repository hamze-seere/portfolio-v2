'use client'

import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react'
import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { GateContext } from '@/lib/decrypt'
import { LEVELS, enterLevel, grantLevel } from '@/lib/store'

gsap.registerPlugin(ScrollTrigger)

/**
 * One clearance level. Opens its decrypt gate once on entry, reports the
 * level in view, and grants clearance (L5 is granted by the footer instead).
 */
export function Section({ level, children }: { level: number; children: ReactNode }) {
  const ref = useRef<HTMLElement>(null)
  const [active, setActive] = useState(false)
  const counter = useRef(0)
  const gate = useMemo(() => ({ active, claim: () => counter.current++ }), [active])
  const meta = LEVELS[level - 1]

  useEffect(() => {
    const el = ref.current
    if (!el) return
    const triggers = [
      ScrollTrigger.create({
        trigger: el,
        scroller: '#doc-pane',
        start: 'top 85%',
        once: true,
        onEnter: () => {
          setActive(true)
          if (level < 5) grantLevel(level)
        },
      }),
      ScrollTrigger.create({
        trigger: el,
        scroller: '#doc-pane',
        start: 'top 50%',
        end: 'bottom 50%',
        onToggle: (self) => self.isActive && enterLevel(level),
      }),
    ]
    return () => triggers.forEach((t) => t.kill())
  }, [level])

  return (
    <GateContext.Provider value={gate}>
      <section
        ref={ref}
        id={meta.id}
        data-level={level}
        aria-labelledby={`${meta.id}-label`}
        className="doc-section relative px-[clamp(20px,5vw,72px)] py-[clamp(72px,12vh,140px)]"
      >
        <header className="mb-10 flex items-baseline justify-between gap-4 border-b border-rule pb-3 font-mono text-[11px] uppercase tracking-[0.14em] text-ink-2">
          <span id={`${meta.id}-label`}>
            L{level} <span className="text-ink-3">/</span> {meta.code.replace('_', ' ')}
          </span>
          <span>
            CLASS: <span className={level >= 4 ? 'text-signal' : ''}>{meta.klass}</span>
          </span>
        </header>
        {children}
      </section>
    </GateContext.Provider>
  )
}
