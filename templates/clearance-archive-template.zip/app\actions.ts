'use server'

import { headers } from 'next/headers'
import { validate, type Fields, type TxState } from '@/lib/transmission'

/*
  Secure channel endpoint. Server actions already enforce same-origin (Origin
  vs Host check). On top: honeypot, minimum fill time, per-IP rate limit,
  server-side re-validation, and length caps before anything is forwarded.
  Delivery: POSTs JSON to CONTACT_WEBHOOK_URL (e.g. a Resend/Slack/n8n hook).
  Without it, transmissions are logged server-side in development only.
*/

const WINDOW_MS = 10 * 60 * 1000
const MAX_PER_WINDOW = 5
const hits = new Map<string, number[]>() // in-memory; use a shared store (KV/Redis) across instances

function limited(ip: string) {
  const now = Date.now()
  const recent = (hits.get(ip) ?? []).filter((t) => now - t < WINDOW_MS)
  recent.push(now)
  hits.set(ip, recent)
  if (hits.size > 5000) hits.clear()
  return recent.length > MAX_PER_WINDOW
}

const str = (v: FormDataEntryValue | null, max: number) => (typeof v === 'string' ? v.slice(0, max) : '')

export async function transmit(_prev: TxState, form: FormData): Promise<TxState> {
  const h = await headers()
  const ip = (h.get('x-forwarded-for') ?? '').split(',')[0].trim() || h.get('x-real-ip') || 'local'

  const fields: Fields = {
    callsign: str(form.get('callsign'), 200),
    channel: str(form.get('channel'), 320),
    subject: str(form.get('subject'), 80),
    message: str(form.get('message'), 5000),
  }

  // Bots fill the decoy field or submit faster than a human can type.
  const decoy = str(form.get('fax'), 200)
  const openedAt = Number(str(form.get('t'), 20))
  const fakeOk: TxState = { status: 'sent', ref: 'TX-' + crypto.randomUUID().slice(0, 8).toUpperCase() }
  if (decoy || !openedAt || Date.now() - openedAt < 3000) return fakeOk

  if (limited(ip)) return { status: 'error', errors: {}, message: 'CHANNEL THROTTLED — TRY AGAIN IN 10 MINUTES' }

  const errors = validate(fields)
  if (Object.keys(errors).length) return { status: 'error', errors }

  const ref = 'TX-' + crypto.randomUUID().slice(0, 8).toUpperCase()
  const payload = { ref, ...fields, receivedAt: new Date().toISOString() }

  const hook = process.env.CONTACT_WEBHOOK_URL
  if (hook) {
    try {
      const res = await fetch(hook, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(8000),
      })
      if (!res.ok) throw new Error(String(res.status))
    } catch {
      return { status: 'error', errors: {}, message: 'RELAY UNREACHABLE — TRANSMISSION NOT SENT. RETRY.' }
    }
  } else if (process.env.NODE_ENV !== 'production') {
    console.info('[secure-channel]', payload)
  } else {
    return { status: 'error', errors: {}, message: 'RELAY NOT CONFIGURED — USE THE ADDRESS BELOW' }
  }

  return { status: 'sent', ref }
}
