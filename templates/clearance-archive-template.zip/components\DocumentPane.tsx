'use client'

import { useEffect, useRef, type ReactNode } from 'react'
import Lenis from 'lenis'
import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { grantLevel, live, log, registerScroller, store } from '@/lib/store'

gsap.registerPlugin(ScrollTrigger)

/**
 * The only scrolling region. Lenis smooths it (tight lerp — mechanical, not floaty);
 * ScrollTrigger reads it for levels, parallax and the L5 footer grant.
 * Note: Lenis lerp is 0–1 (1 = no smoothing). 0.2 is ~2× tighter than default.
 */
export function DocumentPane({ children }: { children: ReactNode }) {
  const pane = useRef<HTMLElement>(null)
  const content = useRef<HTMLDivElement>(null)
  const lines = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const wrapper = pane.current!
    const inner = content.current!
    const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches
    let lenis: Lenis | null = null
    let maxDepth = 0
    let milestone = 0
    let tickerFn: ((t: number) => void) | null = null

    const onScroll = () => {
      const max = wrapper.scrollHeight - wrapper.clientHeight
      const pct = max > 0 ? Math.round((wrapper.scrollTop / max) * 100) : 0
      live.scroll = wrapper.scrollTop
      if (pct > maxDepth) {
        maxDepth = pct
        store.set({ depth: pct })
        const m = Math.floor(pct / 25) * 25
        if (m > milestone) {
          milestone = m
          log(`› scroll depth: ${m}%`, 'dim')
        }
      }
    }

    if (!reduced) {
      lenis = new Lenis({ wrapper, content: inner, lerp: 0.2, smoothWheel: true, autoRaf: false })
      lenis.on('scroll', (l: Lenis) => {
        live.velocity = l.velocity
        ScrollTrigger.update()
        onScroll()
      })
      tickerFn = (t: number) => lenis!.raf(t * 1000)
      gsap.ticker.add(tickerFn)
      gsap.ticker.lagSmoothing(0)
    } else {
      wrapper.addEventListener('scroll', onScroll, { passive: true })
    }

    registerScroller({
      toLevel(n, immediate) {
        const el = wrapper.querySelector<HTMLElement>(`[data-level="${n}"]`)
        if (!el) return
        if (lenis) lenis.scrollTo(el, immediate ? { immediate: true, force: true } : { duration: 0.9, easing: (t) => 1 - Math.pow(1 - t, 4), lock: true })
        else wrapper.scrollTop = el.offsetTop
      },
      stop: () => lenis?.stop(),
      start: () => lenis?.start(),
    })

    // Blueprint lines drift at 0.3× scroll: they ride the content (1×) and counter-move 0.7×.
    const ctx = gsap.context(() => {
      if (!reduced && lines.current) {
        gsap.to(lines.current, {
          y: () => (inner.scrollHeight - wrapper.clientHeight) * 0.7,
          ease: 'none',
          scrollTrigger: { scroller: wrapper, trigger: inner, start: 'top top', end: 'bottom bottom', scrub: true, invalidateOnRefresh: true },
        })
      }
      ScrollTrigger.create({
        scroller: wrapper,
        trigger: '#archive-footer',
        start: 'top bottom-=40',
        onEnter: () => grantLevel(5),
      })
    })

    const ro = new ResizeObserver(() => ScrollTrigger.refresh())
    ro.observe(inner)

    return () => {
      ro.disconnect()
      ctx.revert()
      registerScroller(null)
      wrapper.removeEventListener('scroll', onScroll)
      if (tickerFn) gsap.ticker.remove(tickerFn)
      lenis?.destroy()
    }
  }, [])

  return (
    <main
      id="doc-pane"
      ref={pane}
      tabIndex={-1}
      className="doc-pane tex-paper relative h-full min-h-0 overflow-y-auto overscroll-contain bg-paper outline-none"
    >
      <div ref={content} className="relative [overflow:clip]">
        <div ref={lines} className="blueprint-lines pointer-events-none absolute inset-0" aria-hidden="true" />
        <div className="relative">{children}</div>
      </div>
    </main>
  )
}
