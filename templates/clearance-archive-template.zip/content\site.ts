/*
  Archive manifest. Everything a visitor reads outside the MDX bodies lives here.
  Projects and notes below are SAMPLE CONTENT — replace with real work.
*/

export const site = {
  name: 'Hamse Ayuub',
  fileNo: 'HA-0417',
  role: ['Security Engineer', 'Designer / Developer'],
  thesis: 'I break systems for a living and build interfaces for a reason: the safest product is the one people can actually use correctly.',
  location: 'Remote — UTC+3',
  status: 'ACTIVE — accepting engagements',
  email: 'channel@example.com',
}

export type Project = {
  slug: string
  code: string
  title: string
  year: string
  client: string
  role: string
  stack: string
  security: string
  design: string
  outcome: string
  plate: { src: string; alt: string; w: number; h: number }
}

export const projects: Project[] = [
  {
    slug: 'vaultline',
    code: 'PROJECT_01',
    title: 'Vaultline',
    year: '2026',
    client: 'Regional credit union',
    role: 'Lead security engineer + design system owner',
    stack: 'Next.js · Go · Postgres · WebAuthn',
    security: 'STRIDE threat model, WebAuthn step-up for privileged actions, append-only signed audit log.',
    design: 'Dense, keyboard-first admin console on a 44-component system with explicit danger states.',
    outcome: 'Privileged-action incidents: 0 in 9 months. Admin task time −31%.',
    plate: { src: '/plates/vaultline.svg', alt: 'Schematic of the step-up authentication flow between console, policy engine and hardware key', w: 960, h: 600 },
  },
  {
    slug: 'patchwork',
    code: 'PROJECT_02',
    title: 'Patchwork',
    year: '2025',
    client: 'Series-C logistics platform',
    role: 'AppSec engineer + product designer',
    stack: 'React · Python · SBOM (CycloneDX) · EPSS',
    security: 'SBOM ingestion and reachability analysis; prioritisation on EPSS × exposure instead of raw CVSS.',
    design: 'A triage queue that shows one decision at a time, with the evidence that justifies it.',
    outcome: 'Median time-to-triage 6 days → 9 hours. Backlog −74%.',
    plate: { src: '/plates/patchwork.svg', alt: 'Triage queue wireframe with exposure, exploitability and owner columns', w: 960, h: 600 },
  },
  {
    slug: 'quietroom',
    code: 'PROJECT_03',
    title: 'Quietroom',
    year: '2025',
    client: 'Internal — incident response team',
    role: 'IR tooling lead',
    stack: 'SvelteKit · Rust · S3 Object Lock',
    security: 'Evidence chain-of-custody with hash-chained artefacts and WORM storage; role-scoped war rooms.',
    design: 'Calm-under-pressure UI: one timeline, muted palette, nothing that blinks unless it must.',
    outcome: 'Used in 23 live incidents. Post-incident report prep −60%.',
    plate: { src: '/plates/quietroom.svg', alt: 'Incident timeline diagram with hash-chained evidence nodes', w: 960, h: 600 },
  },
  {
    slug: 'papertrail',
    code: 'PROJECT_04',
    title: 'Papertrail',
    year: '2024',
    client: 'Fintech (payments)',
    role: 'Penetration tester → UX remediation',
    stack: 'Burp Suite · Semgrep · Figma · Remix',
    security: 'Found IDOR on statements, session fixation on recovery, and an SSRF in a PDF renderer.',
    design: 'Rebuilt sign-in and account recovery so the secure path is also the shortest path.',
    outcome: '3 criticals closed in 11 days. Recovery-flow support tickets −45%.',
    plate: { src: '/plates/papertrail.svg', alt: 'Annotated account recovery flow showing the removed session-fixation branch', w: 960, h: 600 },
  },
  {
    slug: 'signalfire',
    code: 'PROJECT_05',
    title: 'Signalfire',
    year: '2024',
    client: 'Security startup (seed)',
    role: 'Design + frontend + hardening',
    stack: 'Astro · Cloudflare · Nonce CSP',
    security: 'Strict nonce CSP, Trusted Types, SRI, zero third-party requests on first load.',
    design: 'Editorial launch site with a motion system that degrades to a static print layout.',
    outcome: 'A+ headers on launch day. LCP 0.9s on 4G.',
    plate: { src: '/plates/signalfire.svg', alt: 'Request diagram showing the site making zero third-party connections', w: 960, h: 600 },
  },
]

export type Note = { slug: string; code: string; title: string; summary: string; date: string; minutes: number }

export const notes: Note[] = [
  {
    slug: 'redaction-is-material',
    code: 'NOTE 04-01',
    title: 'Redaction is a design material',
    summary: 'What you hide shapes what people trust. Treat absence like typography.',
    date: '2026-09-14',
    minutes: 5,
  },
  {
    slug: 'csp-is-a-style-guide',
    code: 'NOTE 04-02',
    title: 'Your CSP is a style guide for scripts',
    summary: 'A content security policy is a design constraint. Good constraints make better systems.',
    date: '2026-06-02',
    minutes: 7,
  },
  {
    slug: 'threat-modeling-with-a-pencil',
    code: 'NOTE 04-03',
    title: 'Threat modeling with a pencil',
    summary: 'The best threat models I have run started as sketches, not spreadsheets.',
    date: '2026-02-19',
    minutes: 6,
  },
  {
    slug: 'dark-patterns-are-vulns',
    code: 'NOTE 04-04',
    title: 'Dark patterns are security bugs',
    summary: 'If an interface tricks the user, an attacker can borrow the trick.',
    date: '2025-11-30',
    minutes: 4,
  },
]

export const capabilities = {
  security: [
    { id: 'S.01', name: 'Penetration testing', note: 'web · API · cloud — OWASP WSTG, authz & business logic', level: 9 },
    { id: 'S.02', name: 'Threat modeling', note: 'STRIDE, attack trees, data-flow diagrams drawn with the team', level: 9 },
    { id: 'S.03', name: 'Application security', note: 'secure SDLC, SAST/DAST in CI, dependency & SBOM hygiene', level: 8 },
    { id: 'S.04', name: 'Incident response', note: 'triage, containment, forensics hand-off, blameless reports', level: 7 },
  ],
  craft: [
    { id: 'C.01', name: 'Design systems', note: 'tokens, component APIs, documentation that gets read', level: 9 },
    { id: 'C.02', name: 'Frontend engineering', note: 'React / Next.js, TypeScript, accessibility to WCAG 2.2 AA', level: 9 },
    { id: 'C.03', name: 'Interaction & motion', note: 'springs, scroll systems, reduced-motion parity', level: 8 },
    { id: 'C.04', name: 'Editorial & type', note: 'grids, specimen sheets, print-grade layouts', level: 7 },
  ],
}
