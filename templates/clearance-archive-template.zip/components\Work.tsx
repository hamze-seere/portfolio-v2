'use client'

import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react'
import { motion } from 'framer-motion'
import { Decrypt } from './Decrypt'
import { Dossier } from './Dossier'
import { Lock } from './Lock'
import { Plate } from './Plate'
import { Redacted } from './Redacted'
import { registerOpener, useStore } from '@/lib/store'
import type { Project } from '@/content/site'

/*
  Terminal → Specimen. Each card starts as raw, truncated manifest output and
  resolves into a designed specimen on hover/focus: the dev→design duality in
  one 300ms interaction. Touch devices (no hover) see the specimen directly.
*/
const MORPH = { type: 'spring', duration: 0.3, bounce: 0 } as const
const trunc = (s: string, n: number) => (s.length > n ? s.slice(0, n - 1) + '…' : s)

function hash(s: string) {
  let h = 0x811c9dc5
  for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 0x01000193)
  return (h >>> 0).toString(16).padStart(8, '0')
}

// Real bytes of the security brief, xxd-style.
function hexdump(s: string, lines: number) {
  const bytes = Array.from(new TextEncoder().encode(s))
  return Array.from({ length: lines }, (_, i) => {
    const row = bytes.slice(i * 8, i * 8 + 8)
    const hex = row.map((b) => b.toString(16).padStart(2, '0')).join(' ').padEnd(23)
    const txt = row.map((b) => (b >= 32 && b < 127 ? String.fromCharCode(b) : '.')).join('')
    return `${(i * 8).toString(16).padStart(8, '0')}  ${hex}  |${txt}|`
  }).join('\n')
}

function Card({ p, onOpen, touch }: { p: Project; onOpen: () => void; touch: boolean }) {
  const [hot, setHot] = useState(false)
  const reduced = useStore((s) => s.reduced)
  const show = touch || hot
  const t = reduced ? { duration: 0.15 } : MORPH

  return (
    <motion.article
      className="card @container group relative grid border border-ink bg-paper"
      data-log={p.code}
      onPointerEnter={() => setHot(true)}
      onPointerLeave={() => setHot(false)}
      onFocus={() => setHot(true)}
      onBlur={(e) => !e.currentTarget.contains(e.relatedTarget as Node) && setHot(false)}
      initial="rest"
      animate={show ? 'open' : 'rest'}
    >
      {/* Layer 1 — terminal output */}
      <motion.div
        aria-hidden={show}
        className="tex-vellum col-start-1 row-start-1 bg-console p-5 font-mono text-[12px] leading-[1.65] text-amber"
        animate={{ opacity: show ? 0 : 1, clipPath: show ? 'inset(0 0 100% 0)' : 'inset(0 0 0% 0)' }}
        transition={t}
      >
        <div className="text-amber-dim">$ cat ./archive/{p.slug}.manifest | head -n 7</div>
        <div>&gt; id&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{p.code}</div>
        <div>&gt; name&nbsp;&nbsp;&nbsp;&nbsp;{p.title.toUpperCase()} ({p.year})</div>
        <div>&gt; role&nbsp;&nbsp;&nbsp;&nbsp;{trunc(p.role, 34)}</div>
        <div>&gt; sec&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{trunc(p.security, 34)}</div>
        <div>&gt; design&nbsp;&nbsp;{trunc(p.design, 34)}</div>
        <div>&gt; fnv1a&nbsp;&nbsp;&nbsp;{hash(p.slug + p.title)}</div>
        <div className="mt-3 text-amber-dim">$ xxd ./archive/{p.slug}.sec | head</div>
        <pre className="overflow-hidden text-[11px] leading-[1.55] text-amber-dim">{hexdump(p.security, 6)}</pre>
        <div className="mt-2 text-amber-dim">[ output truncated — hover to resolve ]</div>
      </motion.div>

      {/* Layer 2 — designed specimen */}
      <motion.div
        className="col-start-1 row-start-1 grid gap-5 p-5 @2xl:grid-cols-[1fr_1.1fr]"
        animate={{ opacity: show ? 1 : 0, clipPath: show ? 'inset(0 0 0% 0)' : 'inset(100% 0 0 0)' }}
        transition={t}
        style={{ pointerEvents: show ? 'auto' : 'none' }}
      >
        <Plate src={p.plate.src} alt={p.plate.alt} fig={`FIG.${p.code.slice(-2)}`} width={p.plate.w} height={p.plate.h} />
        <div className="flex flex-col">
          <div className="flex justify-between font-mono text-[10px] uppercase tracking-[0.14em] text-ink-2">
            <span>{p.code}</span>
            <span>{p.year}</span>
          </div>
          <h3 className="font-serif mt-2 text-[clamp(34px,3.6vw,52px)] leading-[0.95] text-ink">{p.title}</h3>
          <div className="mt-1 font-mono text-[11px] text-ink-2">
            Client: <Redacted seed={`${p.slug}-client`} label="client">{p.client}</Redacted>
          </div>
          <dl className="mt-4 grid grid-cols-2 gap-x-4 border-t border-ink pt-3 text-[13px] leading-snug">
            <dt className="font-mono text-[10px] uppercase tracking-[0.12em] text-signal">Security angle</dt>
            <dt className="font-mono text-[10px] uppercase tracking-[0.12em] text-blueprint">Design angle</dt>
            <dd className="mt-1 font-display text-[15px] tracking-[0.01em]">{p.security}</dd>
            <dd className="mt-1 font-display text-[15px] tracking-[0.01em]">{p.design}</dd>
          </dl>
          <div className="mt-auto flex items-end justify-between gap-3 pt-4">
            <span className="font-mono text-[10px] uppercase tracking-[0.1em] text-ink-3">{p.stack}</span>
            <motion.button
              onClick={onOpen}
              className="cta relative flex shrink-0 items-center gap-2 border border-ink bg-ink px-3 py-2 font-mono text-[11px] uppercase tracking-[0.12em] text-paper"
              initial="rest"
              whileHover="open"
              whileFocus="open"
              data-log={`OPEN_${p.code}`}
            >
              <Lock />
              Open dossier
            </motion.button>
          </div>
        </div>
      </motion.div>
    </motion.article>
  )
}

export function Work({ items, bodies }: { items: Project[]; bodies: Record<string, ReactNode> }) {
  const [openSlug, setOpenSlug] = useState<string | null>(null)
  const [touch, setTouch] = useState(false)
  const close = useCallback(() => setOpenSlug(null), [])
  const found = useMemo(() => items.find((p) => p.slug === openSlug), [items, openSlug])
  // Keep the last project mounted through the dossier's exit fold.
  const last = useRef<Project | undefined>(undefined)
  if (found) last.current = found
  const current = last.current

  useEffect(() => {
    setTouch(matchMedia('(hover: none)').matches)
    return registerOpener('project', setOpenSlug)
  }, [])

  return (
    <>
      <h2 className="font-display text-[clamp(44px,6vw,88px)] uppercase leading-[0.86] text-ink">
        <Decrypt text="Selected work" />
      </h2>
      <p className="mt-4 max-w-[52ch] text-[17px] leading-relaxed text-ink-2">
        <Decrypt text="Five case files. Each one was a security problem and a design problem at the same time — hover to resolve the raw output into the finished specimen." />
      </p>
      <div className="mt-12 grid gap-6">
        {items.map((p) => (
          <Card key={p.slug} p={p} touch={touch} onOpen={() => setOpenSlug(p.slug)} />
        ))}
      </div>
      <Dossier
        open={!!found}
        onClose={close}
        code={current?.code ?? ''}
        title={current?.title ?? ''}
        meta={
          current
            ? [
                ['Year', current.year],
                ['Client', <Redacted key="c" seed={`${current.slug}-dossier-client`}>{current.client}</Redacted>],
                ['Role', current.role],
                ['Stack', current.stack],
                ['Security', current.security],
                ['Design', current.design],
                ['Outcome', current.outcome],
              ]
            : []
        }
      >
        {current && (
          <>
            <Plate src={current.plate.src} alt={current.plate.alt} fig={`FIG.${current.code.slice(-2)}`} width={current.plate.w} height={current.plate.h} className="mb-8" />
            {bodies[current.slug]}
          </>
        )}
      </Dossier>
    </>
  )
}
