'use client'

import { useEffect, useRef, type ReactNode } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Decrypt } from './Decrypt'
import { GateContext } from '@/lib/decrypt'
import { lockScroll, log, useStore } from '@/lib/store'

/*
  Case-file dossier. Unfolds like a letter: the header sits flat, the body
  folds down from it, the foot folds down from the body, then the stamp
  lands. Paper grain throughout. Focus is trapped while open and restored after.
*/
type Props = {
  open: boolean
  onClose: () => void
  code: string
  title: string
  stamp?: string
  meta?: [string, ReactNode][]
  children: ReactNode
}

const FOLD = { type: 'spring', stiffness: 170, damping: 22, mass: 0.9 } as const

export function Dossier({ open, onClose, code, title, stamp = 'DECLASSIFIED', meta = [], children }: Props) {
  const sheet = useRef<HTMLDivElement>(null)
  const closeBtn = useRef<HTMLButtonElement>(null)
  const returnTo = useRef<Element | null>(null)
  const reduced = useStore((s) => s.reduced)
  const close = useRef(onClose)
  close.current = onClose

  useEffect(() => {
    if (!open) return
    returnTo.current = document.activeElement
    lockScroll(true)
    log(`› dossier opened: ${code}`)
    requestAnimationFrame(() => closeBtn.current?.focus())

    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation()
        close.current()
      }
      if (e.key !== 'Tab' || !sheet.current) return
      const f = sheet.current.querySelectorAll<HTMLElement>('a[href],button,input,textarea,select,[tabindex]:not([tabindex="-1"])')
      if (!f.length) return
      const first = f[0]
      const last = f[f.length - 1]
      if (e.shiftKey && document.activeElement === first) (e.preventDefault(), last.focus())
      else if (!e.shiftKey && document.activeElement === last) (e.preventDefault(), first.focus())
    }
    document.addEventListener('keydown', onKey)
    return () => {
      document.removeEventListener('keydown', onKey)
      lockScroll(false)
      log(`› dossier sealed: ${code}`, 'dim')
      ;(returnTo.current as HTMLElement | null)?.focus?.()
    }
  }, [open, code])

  const fold = (from: number, delay: number) =>
    reduced
      ? { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 }, transition: { duration: 0.2 } }
      : {
          initial: { rotateX: from, opacity: 0.4 },
          animate: { rotateX: 0, opacity: 1, transition: { ...FOLD, delay } },
          exit: { rotateX: from, opacity: 0, transition: { duration: 0.18, ease: [0.4, 0, 1, 1] as const } },
        }

  return (
    // Dossiers decrypt on open, never on their section gate.
    <GateContext.Provider value={null}>
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-50 flex items-start justify-center overflow-hidden p-3 sm:p-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.18 }}
        >
          <div className="absolute inset-0 bg-ink/70" onClick={onClose} aria-hidden="true" />
          <div
            ref={sheet}
            role="dialog"
            aria-modal="true"
            aria-labelledby="dossier-title"
            className="dossier relative flex max-h-full w-full max-w-[880px] flex-col [perspective:1800px]"
          >
            <motion.header {...fold(0, 0)} className="tex-paper relative border border-ink bg-paper px-6 pb-5 pt-5 sm:px-10">
              <div className="flex items-center justify-between font-mono text-[10px] uppercase tracking-[0.14em] text-ink-2">
                <span>Case file // {code}</span>
                <button ref={closeBtn} onClick={onClose} className="border border-ink px-2 py-1 text-ink hover:bg-ink hover:text-paper">
                  Seal file [Esc]
                </button>
              </div>
              <h2 id="dossier-title" className="font-serif mt-4 text-[clamp(40px,6vw,76px)] leading-[0.92] text-ink">
                <Decrypt text={title} />
              </h2>
              <motion.span
                className="stamp absolute right-8 top-16 hidden sm:block"
                initial={reduced ? { opacity: 0 } : { opacity: 0, scale: 2.4, rotate: -24 }}
                animate={reduced ? { opacity: 1 } : { opacity: 1, scale: 1, rotate: -9, transition: { type: 'spring', stiffness: 420, damping: 18, delay: 0.55 } }}
                aria-hidden="true"
              >
                {stamp}
              </motion.span>
            </motion.header>

            <motion.div
              {...fold(-92, 0.08)}
              style={{ transformOrigin: 'top center' }}
              className="tex-paper relative min-h-0 flex-1 overflow-y-auto overscroll-contain border-x border-b border-ink bg-paper px-6 py-6 sm:px-10"
              data-lenis-prevent
            >
              {meta.length > 0 && (
                <dl className="mb-8 grid grid-cols-1 border-t border-ink font-mono text-[11px] sm:grid-cols-2">
                  {meta.map(([k, v]) => (
                    <div key={k} className="flex gap-3 border-b border-rule py-2 sm:odd:pr-4">
                      <dt className="w-24 shrink-0 uppercase tracking-[0.1em] text-ink-3">{k}</dt>
                      <dd className="text-ink">{v}</dd>
                    </div>
                  ))}
                </dl>
              )}
              <div className="prose-dossier">{children}</div>
            </motion.div>

            <motion.footer
              {...fold(92, 0.22)}
              style={{ transformOrigin: 'top center' }}
              className="tex-paper flex justify-between border-x border-b border-ink bg-paper-2 px-6 py-3 font-mono text-[10px] uppercase tracking-[0.14em] text-ink-2 sm:px-10"
            >
              <span>End of file</span>
              <span>Handle via authorised channels only</span>
            </motion.footer>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
    </GateContext.Provider>
  )
}
