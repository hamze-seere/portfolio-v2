'use client'

import { useRef, useState } from 'react'

/*
  Figure plate under the blueprint probe: on hover it draws dimension lines,
  snaps a crosshair to an 8px grid, warps the image through an SVG
  feDisplacementMap, and prints the alt text as a technical annotation.
*/
const SNAP = 8

type Props = { src: string; alt: string; fig: string; width: number; height: number; className?: string }

export function Plate({ src, alt, fig, width, height, className = '' }: Props) {
  const box = useRef<HTMLDivElement>(null)
  const [probe, setProbe] = useState<{ x: number; y: number; w: number; h: number } | null>(null)

  const move = (e: React.PointerEvent) => {
    const r = box.current!.getBoundingClientRect()
    const x = Math.round((e.clientX - r.left) / SNAP) * SNAP
    const y = Math.round((e.clientY - r.top) / SNAP) * SNAP
    setProbe({ x, y, w: Math.round(r.width), h: Math.round(r.height) })
  }

  return (
    <figure className={`plate relative ${className}`} data-probing={probe ? '' : undefined}>
      <div ref={box} className="relative overflow-hidden border border-ink" onPointerMove={move} onPointerLeave={() => setProbe(null)}>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={src} alt={alt} width={width} height={height} loading="lazy" decoding="async" className="plate-img block h-auto w-full" />
        {probe && (
          <svg className="pointer-events-none absolute inset-0 h-full w-full text-blueprint" aria-hidden="true">
            <g stroke="currentColor" strokeWidth="1" fill="none">
              {/* snapped crosshair */}
              <line x1={probe.x} y1="0" x2={probe.x} y2="100%" strokeDasharray="2 3" />
              <line x1="0" y1={probe.y} x2="100%" y2={probe.y} strokeDasharray="2 3" />
              <rect x={probe.x - 3} y={probe.y - 3} width="6" height="6" />
              {/* dimension lines */}
              <line x1="6" y1="10" x2={probe.w - 6} y2="10" />
              <line x1="6" y1="5" x2="6" y2="15" />
              <line x1={probe.w - 6} y1="5" x2={probe.w - 6} y2="15" />
              <line x1="10" y1="22" x2="10" y2={probe.h - 6} />
              <line x1="5" y1="22" x2="15" y2="22" />
              <line x1="5" y1={probe.h - 6} x2="15" y2={probe.h - 6} />
            </g>
          </svg>
        )}
        {probe && (
          <>
            <span className="plate-dim left-1/2 top-[3px] -translate-x-1/2">W {probe.w}px</span>
            <span className="plate-dim left-[16px] top-1/2 -translate-y-1/2">H {probe.h}px</span>
            <span className="plate-dim" style={{ left: Math.min(probe.x + 8, probe.w - 120), top: Math.min(probe.y + 8, probe.h - 22) }}>
              SNAP {probe.x},{probe.y}
            </span>
          </>
        )}
      </div>
      <figcaption className="mt-2 flex gap-3 font-mono text-[10px] uppercase leading-snug tracking-[0.1em] text-ink-2">
        <span className="shrink-0 text-blueprint">{fig}</span>
        <span>
          {probe ? <span className="text-blueprint">ANNOT // alt: </span> : null}
          {alt}
        </span>
      </figcaption>
    </figure>
  )
}
