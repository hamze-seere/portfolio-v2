'use client'

import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react'
import { motion } from 'framer-motion'
import { Decrypt } from './Decrypt'
import { Dossier } from './Dossier'
import { Redacted } from './Redacted'
import { log, registerOpener, useStore } from '@/lib/store'
import type { Note } from '@/content/site'

/*
  L4 — Declassified notes. Metadata is redacted until probed; opening a note
  decrypts its title. The last row is the hidden file: ACCESS DENIED three
  times, opened on the fourth attempt. Persistence is the only credential.
*/
export function Notes({ items, bodies, omega }: { items: Note[]; bodies: Record<string, ReactNode>; omega: ReactNode }) {
  const [openSlug, setOpenSlug] = useState<string | null>(null)
  const [attempts, setAttempts] = useState(0)
  const [denied, setDenied] = useState(0)
  const reduced = useStore((s) => s.reduced)
  const lastNote = useRef<Note | null>(null)
  const close = useCallback(() => setOpenSlug(null), [])

  const current = items.find((n) => n.slug === openSlug) ?? null
  if (current) lastNote.current = current
  const shown = current ?? lastNote.current

  const tries = useRef(0)
  const tryOmega = useCallback(() => {
    const n = ++tries.current
    setAttempts(n)
    if (n < 4) {
      log(`› ACCESS DENIED: FILE_Ω (attempt ${n}/3)`, 'warn')
      setDenied((d) => d + 1)
    } else {
      if (n === 4) log('› override accepted — persistence logged as credential', 'grant')
      setOpenSlug('omega')
    }
  }, [])

  useEffect(() => registerOpener('note', (slug) => (slug === 'omega' ? tryOmega() : setOpenSlug(slug))), [tryOmega])

  return (
    <>
      <h2 className="font-display text-[clamp(44px,6vw,88px)] uppercase leading-[0.86] text-ink">
        <Decrypt text="Declassified notes" />
      </h2>
      <p className="mt-4 max-w-[52ch] text-[17px] leading-relaxed text-ink-2">
        <Decrypt text="Field notes where security and design overlap. Dates and reading times are redacted until you look." />
      </p>

      <ol className="mt-12 border-t border-ink">
        {items.map((n) => (
          <li key={n.slug} className="border-b border-rule">
            <div className="grid grid-cols-[auto_1fr] items-baseline gap-x-6 gap-y-2 py-5 sm:grid-cols-[110px_1fr_auto]">
              <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-ink-3">{n.code}</span>
              <button className="note-link text-left" onClick={() => setOpenSlug(n.slug)} data-log={n.code.replace(' ', '_')}>
                <span className="font-display text-[clamp(24px,2.4vw,32px)] uppercase leading-[1] text-ink">{n.title}</span>
                <span className="mt-1 block text-[15px] leading-snug text-ink-2">{n.summary}</span>
              </button>
              <span className="col-start-2 font-mono text-[10px] uppercase tracking-[0.1em] text-ink-2 sm:col-start-3">
                <Redacted seed={`${n.slug}-date`} label="date">{n.date}</Redacted>
                {' · '}
                <Redacted seed={`${n.slug}-min`} label="reading time">{n.minutes} min</Redacted>
              </span>
            </div>
          </li>
        ))}
        <li className="border-b border-rule">
          <div className="grid grid-cols-[auto_1fr] items-baseline gap-x-6 py-5 sm:grid-cols-[110px_1fr_auto]">
            <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-signal">NOTE Ω</span>
            <button onClick={tryOmega} className="text-left" data-log="FILE_Ω" aria-describedby="omega-status">
              <span className="omega-bar inline-block h-[0.9em] w-[min(320px,60vw)] bg-ink align-middle" aria-hidden="true" />
              <span className="sr-only">Sealed file. Request access.</span>
            </button>
            <motion.span
              key={denied}
              id="omega-status"
              role="status"
              className="col-start-2 font-mono text-[10px] uppercase tracking-[0.14em] text-signal sm:col-start-3"
              initial={denied && !reduced ? { x: -6 } : false}
              animate={{ x: 0 }}
              transition={{ type: 'spring', stiffness: 900, damping: 9 }}
            >
              {attempts === 0 ? 'Sealed' : attempts < 4 ? `Access denied ${attempts}/3` : 'Override accepted'}
            </motion.span>
          </div>
        </li>
      </ol>

      <Dossier open={!!current} onClose={close} code={shown?.code ?? ''} title={shown?.title ?? ''} meta={shown ? [['Filed', shown.date], ['Reading', `${shown.minutes} min`]] : []}>
        {shown && bodies[shown.slug]}
      </Dossier>
      <Dossier open={openSlug === 'omega'} onClose={close} code="NOTE Ω" title="For the archivist" stamp="EYES ONLY">
        {omega}
      </Dossier>
    </>
  )
}
