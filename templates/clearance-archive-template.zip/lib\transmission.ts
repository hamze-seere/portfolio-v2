/* Shared validation for the secure-channel form — runs in the browser and again on the server. */

export const CHANNELS = ['Security engagement', 'Design / build engagement', 'Both — the interesting kind', 'Something else'] as const

export type Fields = { callsign: string; channel: string; subject: string; message: string }
export type Errors = Partial<Record<keyof Fields, string>>

const EMAIL = /^[^\s@<>()[\]\\,;:"]{1,64}@[^\s@<>()[\]\\,;:"]{1,253}\.[a-z]{2,24}$/i

export function validate(f: Fields): Errors {
  const e: Errors = {}
  const name = f.callsign.trim()
  if (name.length < 2) e.callsign = 'CALLSIGN TOO SHORT — 2 CHARS MIN'
  else if (name.length > 80) e.callsign = 'CALLSIGN EXCEEDS 80 CHARS'
  if (!EMAIL.test(f.channel.trim())) e.channel = 'RETURN CHANNEL MALFORMED — EXPECTED name@domain.tld'
  if (!CHANNELS.includes(f.subject as (typeof CHANNELS)[number])) e.subject = 'SELECT A TRANSMISSION CLASS'
  const msg = f.message.trim()
  if (msg.length < 20) e.message = `PAYLOAD TOO SHORT — ${20 - msg.length} MORE CHARS REQUIRED`
  else if (msg.length > 4000) e.message = 'PAYLOAD EXCEEDS 4000 CHARS'
  return e
}

export type TxState =
  | { status: 'idle' }
  | { status: 'error'; errors: Errors; message?: string }
  | { status: 'sent'; ref: string }
