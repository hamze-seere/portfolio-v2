'use client'

import { Decrypt } from './Decrypt'
import { Redacted } from './Redacted'
import { capabilities, site } from '@/content/site'

/* L1 — Identity. Decrypts on load. */
export function Identity() {
  return (
    <div className="relative">
      <span className="stamp absolute right-0 top-0 hidden md:block" aria-hidden="true">
        Classified
      </span>
      <div className="font-mono text-[11px] uppercase tracking-[0.14em] text-ink-2">
        Personnel file <span className="text-ink">{site.fileNo}</span>
      </div>
      <h1 className="font-serif mt-6 text-[clamp(64px,10vw,152px)] leading-[0.86] tracking-[-0.01em] text-ink">
        <Decrypt text={site.name} />
      </h1>
      <p className="mt-6 font-display text-[clamp(26px,3.2vw,44px)] uppercase leading-[0.95] text-ink">
        <Decrypt text={site.role[0]} />
        <span className="mx-3 text-signal" aria-hidden="true">
          ×
        </span>
        <span className="sr-only"> and </span>
        <Decrypt text={site.role[1]} />
      </p>
      <p className="mt-8 max-w-[46ch] text-[clamp(18px,1.5vw,21px)] leading-[1.5] text-ink-2">
        <Decrypt text={site.thesis} />
      </p>
      <dl className="mt-12 grid max-w-[640px] grid-cols-2 border-t border-ink font-mono text-[11px] uppercase tracking-[0.08em]">
        {[
          ['Status', site.status],
          ['Location', <Redacted key="l" seed="identity-location" label="location">{site.location}</Redacted>],
          ['Disciplines', 'Offense · defense · interface'],
          ['Required clearance', 'L5 to open channel'],
        ].map(([k, v]) => (
          <div key={String(k)} className="border-b border-rule py-2 pr-4">
            <dt className="text-ink-3">{k}</dt>
            <dd className="mt-1 text-ink">{v}</dd>
          </div>
        ))}
      </dl>
      <p className="mt-10 font-mono text-[11px] uppercase tracking-[0.14em] text-ink-3">
        ↓ Scroll to ascend clearance · <span className="text-ink-2">⌘K</span> to query the archive
      </p>
    </div>
  )
}

/* L3 — Capabilities as a specimen sheet: security and craft interleaved, each with a ruler gauge. */
function Ruler({ value }: { value: number }) {
  return (
    <svg viewBox="0 0 101 12" className="h-3 w-[120px] text-ink" role="img" aria-label={`${value} of 10`}>
      {Array.from({ length: 11 }, (_, i) => (
        <line key={i} x1={i * 10 + 0.5} x2={i * 10 + 0.5} y1={i % 5 === 0 ? 0 : 4} y2="12" stroke="currentColor" strokeWidth="1" />
      ))}
      <rect x="0.5" y="7" width={value * 10} height="3" fill="currentColor" />
    </svg>
  )
}

export function Capabilities() {
  const rows = capabilities.security.flatMap((s, i) => [
    { ...s, side: 'security' as const },
    { ...capabilities.craft[i], side: 'craft' as const },
  ])
  return (
    <>
      <h2 className="font-display text-[clamp(44px,6vw,88px)] uppercase leading-[0.86] text-ink">
        <Decrypt text="Capabilities" />
      </h2>
      <p className="mt-4 max-w-[52ch] text-[17px] leading-relaxed text-ink-2">
        <Decrypt text="A specimen sheet. Offense and craft are interleaved on purpose — every row on the left changes how I do the row on its right." />
      </p>
      <div className="specimen mt-12 grid border-t border-ink md:grid-cols-2">
        <div className="hidden border-b border-rule py-2 font-mono text-[10px] uppercase tracking-[0.14em] text-signal md:block">Security // offense &amp; defense</div>
        <div className="hidden border-b border-rule py-2 pl-6 font-mono text-[10px] uppercase tracking-[0.14em] text-blueprint md:block">Craft // design &amp; build</div>
        {rows.map((r) => (
          <div key={r.id} className={`relative border-b border-rule py-6 ${r.side === 'craft' ? 'md:border-l md:pl-6' : 'md:pr-6'}`}>
            <div className="flex items-baseline justify-between font-mono text-[10px] uppercase tracking-[0.14em]">
              <span className={r.side === 'security' ? 'text-signal' : 'text-blueprint'}>{r.id}</span>
              <Ruler value={r.level} />
            </div>
            <h3 className="mt-3 font-display text-[clamp(26px,2.6vw,36px)] uppercase leading-[0.95] text-ink">
              <Decrypt text={r.name} />
            </h3>
            <p className="annot mt-3 font-mono text-[11px] leading-relaxed text-ink-2">
              <span className="text-blueprint">⟶ </span>
              <Decrypt text={r.note} />
            </p>
          </div>
        ))}
      </div>
      <p className="mt-4 font-mono text-[10px] uppercase tracking-[0.12em] text-ink-3">
        Scale: self-assessed, 0–10. Calibrated against people better than me.
      </p>
    </>
  )
}
