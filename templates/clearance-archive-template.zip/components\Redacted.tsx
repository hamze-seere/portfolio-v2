'use client'

import { useEffect, useMemo, useState, type ReactNode } from 'react'
import { log, useStore } from '@/lib/store'

/*
  Redaction bar that burns away on hover/focus in a pixel-dissolve —
  a shredder run backwards: strips reassemble into clear text column by
  column, each bar with its own seeded jitter. The real text is always in
  the DOM (screen readers and print get it); the bar is visual only.
*/
const COLS = 18
const ROWS = 3

function rng(seed: string) {
  let h = 1779033703 ^ seed.length
  for (let i = 0; i < seed.length; i++) h = Math.imul(h ^ seed.charCodeAt(i), 3432918353)
  return () => {
    h = Math.imul(h ^ (h >>> 16), 2246822507)
    h = Math.imul(h ^ (h >>> 13), 3266489909)
    return ((h ^= h >>> 16) >>> 0) / 4294967296
  }
}

export function Redacted({ seed, children, label }: { seed: string; children: ReactNode; label?: string }) {
  const burnAll = useStore((s) => s.burnAll)
  const [burned, setBurned] = useState(false)
  const delays = useMemo(() => {
    const r = rng(seed)
    // Strip order is shuffled per bar; cells within a strip jitter slightly.
    const order = Array.from({ length: COLS }, (_, i) => i).sort(() => r() - 0.5)
    return Array.from({ length: COLS * ROWS }, (_, i) => {
      const col = i % COLS
      return Math.round(order.indexOf(col) * 16 + r() * 70)
    })
  }, [seed])

  useEffect(() => {
    if (burnAll) setBurned(true)
  }, [burnAll])

  const burn = () => {
    if (burned) return
    setBurned(true)
    log(`› redaction burned: ${seed.toUpperCase()}`, 'warn')
  }

  return (
    <span
      className="redacted relative inline-block align-baseline"
      data-burned={burned || undefined}
      tabIndex={burned ? undefined : 0}
      aria-label={burned ? undefined : `Redacted${label ? ` ${label}` : ''}. Focus to declassify.`}
      onPointerEnter={burn}
      onFocus={burn}
    >
      <span className="redacted-text">{children}</span>
      <span className="redacted-bar" aria-hidden="true" style={{ gridTemplateColumns: `repeat(${COLS},1fr)` }}>
        {delays.map((d, i) => (
          <span key={i} style={{ transitionDelay: `${d}ms` }} />
        ))}
      </span>
    </span>
  )
}
