'use client'

import { motion, type Variants } from 'framer-motion'

/*
  Key-lock for CTAs only. The parent motion element owns the hover state
  (initial="rest" whileHover="open" whileFocus="open"); variants propagate here.
  `full` swings the shackle clear — reserved for the secure channel (L5).
*/
const SPRING = { type: 'spring', stiffness: 640, damping: 13, mass: 0.5 } as const

export function Lock({ full = false, className = '' }: { full?: boolean; className?: string }) {
  const shackle: Variants = {
    rest: { y: 0, rotate: 0, transition: SPRING },
    open: full ? { y: -4, rotate: -32, transition: SPRING } : { y: -2.5, rotate: 0, transition: SPRING },
  }
  return (
    <svg width="14" height="17" viewBox="0 0 14 17" className={`inline-block shrink-0 overflow-visible ${className}`} aria-hidden="true">
      <motion.path
        d="M3.5 8V5a3.5 3.5 0 0 1 7 0v3"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.3"
        variants={shackle}
        style={{ originX: '10.5px', originY: '8px' }}
      />
      <rect x="1" y="8" width="12" height="8.5" fill="currentColor" />
      <rect x="6.3" y="10.5" width="1.4" height="3.2" fill="var(--color-paper)" />
    </svg>
  )
}
