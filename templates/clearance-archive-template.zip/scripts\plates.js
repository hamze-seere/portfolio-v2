// Generates the blueprint plates in public/plates. Shapes only — no text, so no font can leak into an <img>.
const fs = require('fs')
const path = require('path')
const OUT = path.join(__dirname, '..', 'public', 'plates')
const W = 960, H = 600, INK = '#161511', BLUE = '#2350a8', RED = '#c4261d', PAPER = '#ece6d8'

function rng(seed) {
  let h = (seed * 2654435761) >>> 0
  return () => { h ^= h << 13; h ^= h >>> 17; h ^= h << 5; return (h >>> 0) / 4294967296 }
}
const box = (x, y, w, h, c = INK) => `<rect x="${x}" y="${y}" width="${w}" height="${h}" stroke="${c}"/>`
const arrow = (x1, y1, x2, y2, c = INK) => `<path d="M${x1} ${y1}L${x2} ${y2}" stroke="${c}"/><circle cx="${x2}" cy="${y2}" r="3.5" fill="${c}" stroke="none"/>`
const bars = (x, y, n, w, r) => Array.from({ length: n }, (_, i) => `<rect x="${x}" y="${y + i * 14}" width="${((0.3 + r() * 0.7) * w).toFixed(1)}" height="5" fill="${INK}" stroke="none" opacity=".75"/>`).join('')

function plate(name, seed, draw) {
  const r = rng(seed)
  let s = ''
  for (let x = 40; x < W; x += 40) s += `<line x1="${x}" y1="0" x2="${x}" y2="${H}" stroke="${BLUE}" stroke-opacity=".12"/>`
  for (let y = 40; y < H; y += 40) s += `<line x1="0" y1="${y}" x2="${W}" y2="${y}" stroke="${BLUE}" stroke-opacity=".12"/>`
  s += `<rect x="20" y="20" width="${W - 40}" height="${H - 40}" stroke="${INK}"/>`
  for (const [x, y] of [[40, 40], [W - 40, 40], [40, H - 40], [W - 40, H - 40]])
    s += `<circle cx="${x}" cy="${y}" r="7" stroke="${INK}"/><path d="M${x - 12} ${y}h24M${x} ${y - 12}v24" stroke="${INK}"/>`
  s += draw(r)
  fs.writeFileSync(path.join(OUT, `${name}.svg`), `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}"><rect width="${W}" height="${H}" fill="${PAPER}"/><g fill="none" stroke-width="1.5">${s}</g></svg>`)
}

plate('vaultline', 1, (r) =>
  box(110, 200, 200, 200) + bars(130, 230, 6, 160, r) + box(400, 140, 180, 120, BLUE) + box(400, 340, 180, 120) + bars(420, 370, 4, 140, r) +
  `<circle cx="770" cy="300" r="70" stroke="${INK}"/><rect x="745" y="270" width="50" height="60" fill="${INK}"/><path d="M752 270v-18a18 18 0 0 1 36 0v18" stroke="${INK}" stroke-width="5"/>` +
  arrow(310, 300, 400, 200, BLUE) + arrow(580, 200, 700, 280, BLUE) + arrow(580, 400, 700, 320) + arrow(310, 300, 400, 400) +
  `<path d="M110 470h470M110 462v16M580 462v16" stroke="${BLUE}"/><rect x="420" y="160" width="40" height="40" fill="${RED}" stroke="none"/>`)

plate('patchwork', 2, (r) => {
  let s = ''
  for (let i = 0; i < 9; i++) {
    const y = 110 + i * 44
    const e = r()
    s += box(90, y, 780, 32) + `<rect x="100" y="${y + 12}" width="${(80 + r() * 200).toFixed(1)}" height="8" fill="${INK}" stroke="none"/>`
    s += `<rect x="460" y="${y + 8}" width="${(e * 120).toFixed(1)}" height="16" fill="${e > 0.7 ? RED : BLUE}" stroke="none" opacity=".85"/><circle cx="${(700 + r() * 120).toFixed(1)}" cy="${y + 16}" r="6" fill="${INK}" stroke="none"/>`
  }
  return s + `<rect x="86" y="106" width="788" height="40" stroke="${RED}" stroke-width="3"/>`
})

plate('quietroom', 3, (r) => {
  let s = `<path d="M80 300H880" stroke="${INK}" stroke-width="2"/>`
  let px = 80
  for (let i = 0; i < 8; i++) {
    const x = 120 + i * 100, up = i % 2 ? -1 : 1, h = Math.round(60 + r() * 90)
    s += `<path d="M${x} 300v${up * h}" stroke="${BLUE}"/>` + box(x - 30, up > 0 ? 300 + h : 300 - h - 44, 60, 44, i === 5 ? RED : INK) + `<rect x="${x - 6}" y="294" width="12" height="12" fill="${INK}" stroke="none"/>`
    if (i) s += `<path d="M${px} 300Q${(px + x) / 2} 250 ${x} 300" stroke="${BLUE}" stroke-dasharray="4 4"/>`
    px = x
  }
  return s
})

plate('papertrail', 4, (r) => {
  let s = ''
  ;[[120, 140], [320, 140], [520, 140], [720, 140], [320, 380], [520, 380]].forEach(([x, y], i) => (s += box(x, y, 140, 90, i === 4 ? RED : INK) + bars(x + 14, y + 18, 3, 110, r)))
  return s + arrow(260, 185, 320, 185) + arrow(460, 185, 520, 185) + arrow(660, 185, 720, 185) + arrow(390, 230, 390, 380, RED) + arrow(460, 425, 520, 425, RED) +
    `<path d="M300 360L480 480M480 360L300 480" stroke="${RED}" stroke-width="3"/><path d="M590 230L790 230" stroke="${BLUE}" stroke-dasharray="6 6"/>`
})

plate('signalfire', 5, () => {
  let s = `<circle cx="480" cy="300" r="70" stroke="${INK}" stroke-width="2"/><circle cx="480" cy="300" r="10" fill="${INK}" stroke="none"/>`
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * Math.PI * 2, x = Math.round(480 + Math.cos(a) * 230), y = Math.round(300 + Math.sin(a) * 190), ok = i < 3
    s += `<path d="M${Math.round(480 + Math.cos(a) * 75)} ${Math.round(300 + Math.sin(a) * 75)}L${x} ${y}" stroke="${ok ? BLUE : RED}"${ok ? '' : ' stroke-dasharray="5 6"'}/>` + box(x - 24, y - 18, 48, 36, ok ? BLUE : RED)
    if (!ok) s += `<path d="M${x - 12} ${y - 10}l24 20M${x + 12} ${y - 10}l-24 20" stroke="${RED}" stroke-width="2"/>`
  }
  return s + `<circle cx="480" cy="300" r="250" stroke="${BLUE}" stroke-dasharray="2 8"/>`
})

console.log(fs.readdirSync(OUT).join(' '))
