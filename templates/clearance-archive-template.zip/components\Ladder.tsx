'use client'

import { useEffect, useRef, useState } from 'react'
import { motion, useSpring, useTransform } from 'framer-motion'
import { LEVELS, log, scrollToLevel, store, useStore } from '@/lib/store'

/*
  Clearance Ladder. L1 sits at the bottom; scrolling ascends.
  Dragging scrubs with stepped magnetic resistance: the thumb lags the pointer
  near each tick and clicks into the next level once you pull past halfway.
*/
const RESIST = 0.22 // fraction of between-tick travel the thumb follows before it snaps

export function Ladder() {
  const level = useStore((s) => s.level)
  const granted = useStore((s) => s.granted)
  const track = useRef<HTMLDivElement>(null)
  const [drag, setDrag] = useState<number | null>(null)
  const pos = drag ?? level
  const spring = useSpring(level, { stiffness: 520, damping: 34, mass: 0.6 })
  useEffect(() => spring.set(pos), [pos, spring])
  const top = useTransform(spring, (v) => `${((5 - v) / 4) * 100}%`)
  const lastSnap = useRef(level)

  const update = (clientY: number) => {
    const r = track.current!.getBoundingClientRect()
    const t = Math.min(1, Math.max(0, (clientY - r.top) / r.height))
    const raw = 5 - t * 4
    const nearest = Math.round(raw)
    setDrag(nearest + (raw - nearest) * RESIST * 2)
    if (nearest !== lastSnap.current) {
      lastSnap.current = nearest
      navigator.vibrate?.(6)
      log(`› ladder: scrub → L${nearest}`)
      scrollToLevel(nearest)
    }
  }

  const release = () => {
    setDrag(null)
    store.set({ dragging: false })
  }

  const go = (n: number, via: string) => {
    n = Math.min(5, Math.max(1, n))
    if (n === level) return
    log(`› ladder: ${via} → L${n}`)
    scrollToLevel(n)
  }

  return (
    <nav aria-label="Clearance ladder" className="ladder relative flex h-full flex-col items-center border-r border-rule bg-paper py-5">
      <span className="rotate-180 font-mono text-[9px] tracking-[0.14em] text-ink-3 [writing-mode:vertical-rl]">CLEARANCE</span>
      <div
        ref={track}
        role="slider"
        tabIndex={0}
        aria-label="Clearance level"
        aria-orientation="vertical"
        aria-valuemin={1}
        aria-valuemax={5}
        aria-valuenow={level}
        aria-valuetext={`Level ${level}, ${LEVELS[level - 1].code}`}
        data-cursor="drag"
        className="relative my-6 w-full flex-1 touch-none outline-none focus-visible:outline focus-visible:outline-1 focus-visible:-outline-offset-1 focus-visible:outline-blueprint"
        onPointerDown={(e) => {
          e.currentTarget.setPointerCapture(e.pointerId)
          lastSnap.current = level
          store.set({ dragging: true })
          update(e.clientY)
        }}
        onPointerMove={(e) => drag !== null && update(e.clientY)}
        onPointerUp={release}
        onPointerCancel={release}
        onKeyDown={(e) => {
          const map: Record<string, number> = { ArrowUp: level + 1, ArrowRight: level + 1, ArrowDown: level - 1, ArrowLeft: level - 1, Home: 1, End: 5 }
          if (e.key in map) {
            e.preventDefault()
            go(map[e.key], 'key')
          }
        }}
      >
        <div className="absolute inset-y-0 left-1/2 w-px bg-ink-3" />
        {Array.from({ length: 33 }, (_, i) => (
          <div key={i} className="absolute left-1/2 h-px w-[5px] -translate-x-1/2 bg-ink-3" style={{ top: `${(i / 32) * 100}%` }} />
        ))}
        {LEVELS.map((l) => {
          const ok = l.n <= granted
          return (
            <div key={l.n} className="absolute left-0 right-0 -translate-y-1/2" style={{ top: `${((5 - l.n) / 4) * 100}%` }}>
              <div className={`mx-auto h-px w-[22px] ${ok ? 'bg-ink' : 'bg-signal'}`} />
              <span className={`absolute left-1/2 top-[6px] -translate-x-1/2 font-mono text-[9px] ${ok ? 'text-ink' : 'text-signal'}`}>L{l.n}</span>
            </div>
          )
        })}
        <motion.div className="absolute left-1/2 -translate-x-1/2 -translate-y-1/2" style={{ top }} aria-hidden="true">
          <div className="h-[9px] w-[30px] border border-ink bg-paper">
            <div className="mx-auto mt-[3px] h-px w-[18px] bg-ink" />
          </div>
        </motion.div>
      </div>
      <span className="font-mono text-[9px] tracking-[0.14em] text-ink-3">{granted}/5</span>
    </nav>
  )
}
